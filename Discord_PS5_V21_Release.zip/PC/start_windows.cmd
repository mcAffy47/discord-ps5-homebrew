@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0"
title Discord - PS5 PC Companion V21
set "PY_EXE="
set "PY_ARGS="
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>nul
  if not errorlevel 1 (
    set "PY_EXE=py"
    set "PY_ARGS=-3"
  )
)
if not defined PY_EXE (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys; exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>nul
    if not errorlevel 1 set "PY_EXE=python"
  )
)
if not defined PY_EXE (
  echo FEHLER: Python 3.9 oder neuer fehlt.
  pause
  popd
  exit /b 1
)
echo ============================================
echo Discord PS5 - V21 PC Upgrade
echo ============================================
echo [1] Echo-Test
echo [2] Discord Audio - Windows Standardmix, kostenlos
echo [3] Discord Audio - separates vorhandenes Ausgabegeraet, kostenlos
echo     Modus 3: kein CABLE-B erforderlich; virtuelles Mikrofon ausgeschlossen.
choice /c 123 /n /m "Modus 1, 2 oder 3 waehlen: "
if errorlevel 3 goto MODE3
if errorlevel 2 goto MODE2
if errorlevel 1 goto MODE1
echo FEHLER: Ungueltige Auswahl.
goto DONE
:MODE1
set "MODE=echo"
set "EXTRA="
goto RUN
:MODE2
set "MODE=discord"
set "EXTRA="
echo Discord AUSGABE: Windows-Standardgeraet. Achtung: Systemtoene koennen mitkommen.
goto RUN
:MODE3
set "MODE=discord"
set "EXTRA=--strict-isolated-audio"
echo Discord AUSGABE: separates Windows-Geraet im naechsten Schritt auswaehlen.
goto RUN
:RUN
%PY_EXE% %PY_ARGS% "%~dp0companion.py" --mode "%MODE%" %EXTRA%
if errorlevel 1 echo FEHLER: Siehe Meldungen oben.
:DONE
pause
popd
