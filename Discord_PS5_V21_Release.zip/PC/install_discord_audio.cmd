@echo off
setlocal
chcp 65001 >nul
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -m pip install --upgrade sounddevice soundcard numpy
) else (
 where python >nul 2>nul
 if errorlevel 1 (
   echo Python nicht gefunden. Installiere Python von https://www.python.org/downloads/
   pause
   exit /b 1
 )
 python -m pip install --upgrade sounddevice soundcard numpy
)
if errorlevel 1 (
 echo FEHLER: Audiopakete konnten nicht installiert werden.
) else (
 echo Python-Audiopakete installiert. VB-CABLE wird separat benoetigt: https://vb-audio.com/Cable/
)
pause
