"""Discord's documented confidential-client Device Authorization flow.
Tokens and client secret stay in memory on the PC. No login/password collection.
"""
import base64
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

API = 'https://discord.com/api/v10'
class DeviceAuthorization:
    def __init__(self, client_id, client_secret, on_code=None, clock=time.monotonic):
        self.client_id=client_id
        self._secret=client_secret
        self._clock=clock
        self._lock=threading.Lock()
        self._stop=threading.Event()
        self._token=None
        self._on_code=on_code
        self._state={'state':'idle' if client_id and client_secret else 'not_configured'}
        self._expires=0

    def snapshot(self):
        with self._lock:
            result=dict(self._state)
            if self._expires:
                result['expires_in']=max(0,int(self._expires-self._clock()))
            return result

    def _publish(self, **values):
        with self._lock:self._state=values

    def _post(self,path,data):
        auth=base64.b64encode((self.client_id+':'+self._secret).encode()).decode()
        req=urllib.request.Request(API+path,data=urllib.parse.urlencode(data).encode(),
            headers={'Content-Type':'application/x-www-form-urlencoded','Authorization':'Basic '+auth})
        try:
            with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
        except urllib.error.HTTPError as exc:
            # Only interpret stable error identifiers, never return the raw body/token.
            try: payload=json.loads(exc.read(4096))
            except (ValueError,OSError):payload={}
            return {'error':payload.get('error','http_'+str(exc.code))}

    def start(self):
        if not self.client_id or not self._secret:
            raise ValueError('Für diesen dokumentierten Gerätefluss fehlen DISCORD_CLIENT_ID oder DISCORD_CLIENT_SECRET am PC.')
        with self._lock:
            if self._state.get('state') in ('starting','pending'):return
            self._state={'state':'starting'}
            self._expires=0
            self._token=None
            self._stop.clear()
        threading.Thread(target=self._run,daemon=True).start()

    def _run(self):
        try:
            reply=self._post('/oauth2/device/authorize',{'scope':'sdk.social_layer'})
            if 'error' in reply:
                self._publish(state='error',message='Discord lehnt die Geräteanmeldung ab. App-Zugang und Konfiguration prüfen.');return
            code=reply.get('user_code','');device_code=reply.get('device_code','')
            if not isinstance(code,str) or not re.fullmatch(r'[A-Za-z0-9-]{4,32}',code) or not isinstance(device_code,str) or not device_code:
                raise ValueError('Invalid device response')
            expires=reply.get('expires_in');interval=reply.get('interval',5)
            if isinstance(expires,bool) or not isinstance(expires,(int,float)) or not 1<=expires<=3600:
                raise ValueError('Invalid expiry')
            if isinstance(interval,bool) or not isinstance(interval,(int,float)) or not 1<=interval<=60:
                raise ValueError('Invalid interval')
            self._expires=self._clock()+expires
            # Construct a trusted Discord URL, do not open provider-supplied domains.
            self._publish(state='pending',user_code=code,verification_uri='https://discord.com/activate',verification_uri_complete='https://discord.com/activate?'+urllib.parse.urlencode({'user_code':code}))
            if self._on_code:
                try:self._on_code(code,int(expires))
                except (OSError,ValueError,RuntimeError):pass
            while not self._stop.wait(interval):
                if self._clock()>=self._expires:
                    self._publish(state='expired',message='Code abgelaufen. Erneut starten.');return
                reply=self._post('/oauth2/token',{'grant_type':'urn:ietf:params:oauth:grant-type:device_code','device_code':device_code})
                error=reply.get('error')
                if error=='authorization_pending':continue
                if error=='slow_down':interval+=5;continue
                if error:
                    self._publish(state='denied' if error=='access_denied' else 'error',message='Geräteanmeldung nicht abgeschlossen. Erneut starten.');return
                token=reply.get('access_token')
                if not isinstance(token,str) or not token:raise ValueError('Missing token')
                # Not an assertion of /users/@me identity or voice-channel membership.
                self._token=token
                self._publish(state='authorized',message='Discord-Autorisierung erhalten. Sprachkanalsteuerung ist noch nicht integriert.');return
            self._publish(state='cancelled')
        except (OSError,ValueError,TypeError):
            self._publish(state='error',message='Geräteanmeldung fehlgeschlagen. Verbindung und App-Konfiguration prüfen.')
        finally:
            if self._on_code:
                try:self._on_code('',0)
                except (OSError,ValueError,RuntimeError):pass
