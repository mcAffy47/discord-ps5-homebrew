#!/usr/bin/env python3
"""Discord PS5 V7 LAN voice gateway. No Cloudflare, no Discord user tokens.

Echo mode works with Python stdlib alone. Discord desktop mode needs Windows
Python packages sounddevice, soundcard and numpy plus a virtual mic device.
Unencrypted UDP is for one trusted private LAN, never expose the port online.
"""
from __future__ import annotations
import argparse
import socket
import struct
import threading
import time

MAGIC=b"PV7A"
FRAMES=256
SIZE=8+FRAMES*2
PORT=43670


def valid(packet:bytes)->bool:
    return len(packet)==SIZE and packet.startswith(MAGIC)


def make_packet(seq:int, audio:bytes)->bytes:
    if len(audio)!=FRAMES*2:raise ValueError("256 mono S16 samples required")
    return MAGIC+struct.pack("<I",seq & 0xffffffff)+audio


def get_sequence(packet:bytes)->int:
    if not valid(packet): raise ValueError("invalid PV7A")
    return struct.unpack_from("<I",packet,4)[0]


def audio_devices():
    try:
        import sounddevice as sd
        print("\n=== WINDOWS AUDIO PLAYBACK DEVICES ===")
        for i,dev in enumerate(sd.query_devices()):
            if dev['max_output_channels']:
                print(f"{i:2d}: {dev['name']}")
    except ImportError:
        print("sounddevice absent: install py -3 -m pip install sounddevice soundcard numpy")


class DiscordAudio:
    """PCM bridge to normal Discord desktop app using OS audio devices."""
    def __init__(self, virtual_name="CABLE Input", return_name="CABLE-B Input", allow_system_mix=True):
        try:
            import sounddevice as sd
            import soundcard as sc
            import numpy as np
        except ImportError as e:
            raise RuntimeError("Windows: py -3 -m pip install sounddevice soundcard numpy") from e
        self.sd,self.sc,self.np=sd,sc,np
        self.return_name=return_name
        self.allow_system_mix=allow_system_mix
        candidates=[(i,d) for i,d in enumerate(sd.query_devices())
                    if virtual_name.lower() in d['name'].lower() and d['max_output_channels']>0]
        if not candidates:
            raise RuntimeError("Kein CABLE Input (VB-CABLE) als Windows-Wiedergabegeraet.\n"
                "Installiere VB-CABLE von https://vb-audio.com/Cable/ und waehle in Discord als MIKROFON 'CABLE Output'.")
        self.device=candidates[0][0]
        self.device_name=candidates[0][1]['name']
        self.latest=bytes(FRAMES*2)
        self.lock=threading.Lock()
        self.stop=threading.Event()
        self.output=None
        self.capture_error=None
        self.t=None
        self.capture_frames=0
        self.capture_peak=0.0
        self.capture_started=False
        self.last_capture_time=0.0
        self.last_stats_time=time.monotonic()

    def start(self):
        self.output=self.sd.OutputStream(device=self.device,channels=1,
            samplerate=48000,blocksize=FRAMES*3,dtype='float32',latency='low')
        self.output.start()
        self.t=threading.Thread(target=self.capture_pc_sound,daemon=True)
        self.t.start()
        print(f"PS5-MIKROFON -> Windows: {self.device_name}")
        print("Discord INPUT: CABLE Output (VB-Audio Virtual Cable)")
        print("Discord OUTPUT: CABLE-B oder separates vorhandenes Windows-Ausgabegeraet.")
        if self.allow_system_mix:
            print("ACHTUNG: Ohne CABLE-B wird der Windows-Systemmix zur PS5 uebertragen.")

    def capture_pc_sound(self):
        try:
            speakers=list(self.sc.all_speakers())
            matching=[s for s in speakers if self.return_name.lower() in s.name.lower()]
            if matching:
                speaker=matching[0]
                print("Dedizierter Discord-Rueckkanal gefunden. Discord OUTPUT auf",speaker.name,"stellen.")
            else:
                default=self.sc.default_speaker()
                print("CABLE-B nicht vorhanden: kostenloser Windows-Ausgabegeraet-Modus.",flush=True)
                if self.allow_system_mix:
                    speaker=default
                    print("WARNUNG: Windows-Standardmix aktiv. Andere PC-Toene koennen auf der PS5 hoerbar sein.",flush=True)
                else:
                    # Dedicated Discord endpoint is free if Windows already exposes
                    # another playback device (HDMI/monitor/USB headset etc.).
                    # Never label the default endpoint as Discord-only.
                    alternatives=[s for s in speakers if (default is None or s.id!=default.id)
                                  and 'cable input' not in s.name.lower()
                                  and 'cable in 16ch' not in s.name.lower()]
                    # Avoid selecting the virtual microphone sink as Discord output:
                    # this would feed the PS5 microphone back to itself.
                    if not alternatives:
                        raise RuntimeError("Kein zweites Windows-Wiedergabegeraet vorhanden. "
                            "Starte Modus 2 fuer den kostenlosen Windows-Systemmix. "
                            "Fuer Discord-only wird ein separates Ausgabegeraet benoetigt.")
                    print("\nVerfuegbare separate Windows-Ausgabegeraete:",flush=True)
                    for idx, candidate in enumerate(alternatives,1):
                        print(f"  [{idx}] {candidate.name}",flush=True)
                    while True:
                        answer=input("Nummer fuer Discord-Rueckkanal (Enter = Abbruch): ").strip()
                        if not answer:
                            raise RuntimeError("Kein Discord-Rueckkanal ausgewaehlt")
                        if answer.isdigit() and 1 <= int(answer) <= len(alternatives):
                            speaker=alternatives[int(answer)-1]
                            break
                        print("Bitte eine gueltige Nummer eingeben.",flush=True)
                    print("WICHTIG: Discord > Sprache & Video > AUSGABE auf genau dieses Geraet stellen:",speaker.name,flush=True)
                    print("Dieses Geraet NICHT als Windows-Standardausgabe benutzen; sonst sind PC-Toene im Rueckkanal.",flush=True)
            if speaker is None:raise RuntimeError("Kein Windows-Ausgabegeraet")
            loopback=self.sc.get_microphone(id=speaker.id,include_loopback=True)
            if loopback is None:raise RuntimeError("Kein WASAPI-Loopback fuer Windows-Ausgabegeraet")
            print("Windows OUTPUT -> PS5:",speaker.name,flush=True)
            self.capture_started=True
            with loopback.recorder(samplerate=48000,blocksize=FRAMES*3) as recorder:
                while not self.stop.is_set():
                    frames=recorder.record(numframes=FRAMES*3)
                    samples=self.np.asarray(frames,dtype='float32')
                    if samples.ndim>1:samples=samples.mean(axis=1)
                    if samples.shape[0]!=FRAMES*3:continue
                    mono=samples.reshape(FRAMES,3).mean(axis=1)
                    pcm=(self.np.clip(mono,-1.0,1.0)*32767).astype('<i2').tobytes()
                    with self.lock:
                        self.latest=pcm
                        self.capture_frames+=FRAMES
                        self.capture_peak=max(self.capture_peak*0.9,float(self.np.max(self.np.abs(mono))))
                        self.last_capture_time=time.monotonic()
        except Exception as exc:
            print("WARNUNG: Windows-Loopback ausgefallen:",exc,flush=True)
            self.capture_error=exc
            self.stop.set()

    def on_ps5_audio(self,packet:bytes)->bytes:
        if self.capture_error is not None:
            raise RuntimeError("Windows-Loopback ausgefallen; Standardausgabegeraet pruefen") from self.capture_error
        pcm=self.np.frombuffer(packet,dtype='<i2').astype(self.np.float32)/32768.0
        stretched=self.np.repeat(pcm,3)
        self.output.write(stretched.reshape(-1,1))
        with self.lock:
            if time.monotonic()-self.last_stats_time>10:
                print("Rueckkanal: peak={:.3f} frames={} {}".format(
                    self.capture_peak,self.capture_frames,
                    "AKTIV" if self.last_capture_time and time.monotonic()-self.last_capture_time<2 else "KEINE DATEN"),flush=True)
                self.last_stats_time=time.monotonic()
            return self.latest

    def close(self):
        self.stop.set()
        if self.output is not None:
            self.output.stop();self.output.close()
        if self.t is not None and self.t.is_alive():self.t.join(timeout=1.0)


def serve(port:int=PORT, mode:str='echo', *, stop_event=None, ready=None, virtual_name='CABLE Input'):
    audio=None
    if mode=='discord':
        audio=DiscordAudio(virtual_name=virtual_name)
        audio.start()
    stats={"rx":0,"tx":0,"bad":0,"peers":set(),"last_seq":0}
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        sock.bind(('0.0.0.0',port));sock.settimeout(0.3)
        print(f"VOICE LAN BRIDGE | UDP {sock.getsockname()[1]} | MODE {mode.upper()}",flush=True)
        print("Keine Cloudflare-Verbindung. PS5 und PC muessen im selben privaten Netzwerk sein.",flush=True)
        if ready is not None:ready.set()
        last=time.monotonic()
        while stop_event is None or not stop_event.is_set():
            try:packet,remote=sock.recvfrom(4096)
            except socket.timeout:
                continue
            if not valid(packet):
                stats['bad']+=1;continue
            stats['rx']+=1;stats['peers'].add(remote[0]);stats['last_seq']=get_sequence(packet)
            try:
                payload=packet[8:] if audio is None else audio.on_ps5_audio(packet[8:])
                sent=sock.sendto(make_packet(stats['last_seq'],payload),remote)
                if sent==SIZE:stats['tx']+=1
            except Exception as e:
                print("AUDIO FEHLER:",e,flush=True)
                if mode=='discord':raise
            if time.monotonic()-last>3:
                print(f"PS5 UDP empfangen {stats['rx']} | gesendet {stats['tx']} | fehlerhafte {stats['bad']} | letzter Partner {remote[0]}",flush=True)
                last=time.monotonic()
    except KeyboardInterrupt:
        pass
    finally:
        sock.close()
        if audio:audio.close()
    return stats


def main():
    parser=argparse.ArgumentParser(description='PS5 V7 UDP audio - Windows PC bridge')
    parser.add_argument('--mode',choices=['echo','discord'],default='echo',
                        help='echo=PS5 Mikrofon zurueck; discord=Windows Discord mit VB-CABLE')
    parser.add_argument('--port',type=int,default=PORT)
    parser.add_argument('--list-devices',action='store_true')
    parser.add_argument('--virtual-name',default='CABLE Input')
    args=parser.parse_args()
    if args.list_devices:return audio_devices()
    serve(port=args.port,mode=args.mode,virtual_name=args.virtual_name)

if __name__=='__main__':main()
