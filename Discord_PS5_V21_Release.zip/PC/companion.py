#!/usr/bin/env python3
"""Discord PS5 V21 companion: browser OAuth identity + PS5 initiated audio.

Connect using the PS5's IP, not a compiled Windows IP. Discord login scopes:
identify only. No Discord user token ever goes to the PS5. Voice transport is
unencrypted LAN PCM and NOT a direct Discord channel connection.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import http.server
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import ipaddress
import json
import os
import secrets
import socket
import select
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from device_auth import DeviceAuthorization

FRAME_BYTES = 512
AUDIO_PORT = 43670
HTTP_PORT = 4747
AUDIO_MAGIC = b'PV7A'
DISCORD_API = 'https://discord.com/api/v10'
REDIRECT = 'http://127.0.0.1:8765/callback'


def packet_valid(data: bytes) -> bool:
    return len(data) == 520 and data[:4] == AUDIO_MAGIC


def audio_packet(seq: int, pcm: bytes) -> bytes:
    if len(pcm) != FRAME_BYTES:
        raise ValueError('Audio PCM must contain exactly 256 mono S16 samples')
    return AUDIO_MAGIC + struct.pack('<I', seq) + pcm


def validate_ip(ip: str) -> str:
    addr = ipaddress.IPv4Address(ip)
    if not addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_multicast or addr.is_unspecified or addr.is_reserved:
        raise ValueError('Nur eine private PS5-Heimnetz-IP verwenden (z. B. 192.0.2.10).')
    return str(addr)


class Companion:
    def __init__(self, ps5_ip: str, pairing: str, client_id: str, mode: str):
        self.ps5_ip = validate_ip(ps5_ip)
        if len(pairing) != 6 or not pairing.isascii() or not pairing.isdigit():
            raise ValueError('Der Kopplungscode muss genau 6 Ziffern haben.')
        self.pairing = pairing
        self.client_id = client_id.strip()
        self.mode = mode
        self.oauth_lock = threading.Lock()
        self.oauth_sessions: dict[str, tuple[str, float]] = {}
        self.linked_username: str | None = None
        self.audio_rx = 0
        self.audio_tx = 0
        self.stop = threading.Event()
        self.oauth_ready = threading.Event()
        self.ps5_http_lock = threading.Lock()
        self.ps5_cookie = None
        self.last_audio_at = 0.0
        self.device_auth=DeviceAuthorization(self.client_id,os.environ.get("DISCORD_CLIENT_SECRET", ""),self.report_device_code)

    @property
    def ps5_url(self) -> str:
        return f'http://{self.ps5_ip}:{HTTP_PORT}'

    def report_discord(self, username: str):
        # Strip characters reserved in the PS5 diagnostic JSON, no access tokens.
        cleaned = ''.join(c if 32 <= ord(c) <= 126 and c not in '\\"' else '_' for c in username)[:32]
        body = (self.pairing + '\n' + cleaned).encode('ascii')
        req = urllib.request.Request(self.ps5_url + '/api/discord/result', data=body,
                                     headers={'Content-Type': 'text/plain'}, method='POST')
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status != 200:
                raise RuntimeError('PS5 refused the Discord login result')
        self.linked_username = cleaned
        print('Discord OAuth verified; PS5 username updated:', cleaned, flush=True)

    def oauth_start(self) -> str:
        if not self.client_id:
            raise ValueError('Discord Client-ID fehlt. In der Developer-App Public Client aktivieren.')
        if not self.client_id.isdecimal():
            raise ValueError('Discord Client-ID muss eine Dezimalzahl sein.')
        state = secrets.token_urlsafe(24)
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode('ascii')).digest()).decode().rstrip('=')
        with self.oauth_lock:
            self.oauth_sessions[state] = (verifier, time.monotonic())
            for key, (_, ts) in list(self.oauth_sessions.items()):
                if time.monotonic() - ts > 600:
                    self.oauth_sessions.pop(key, None)
        params = dict(client_id=self.client_id, redirect_uri=REDIRECT, response_type='code',
                      scope='identify', state=state, code_challenge=challenge, code_challenge_method='S256')
        return 'https://discord.com/oauth2/authorize?' + urllib.parse.urlencode(params)

    def oauth_callback(self, state: str, code: str) -> str:
        with self.oauth_lock:
            found = self.oauth_sessions.pop(state, None)
        if not found or time.monotonic() - found[1] > 600:
            raise ValueError('Ungültiger oder abgelaufener OAuth state.')
        verifier = found[0]
        # Public OAuth client with PKCE. No client_secret, no PC tunnel, no token on PS5.
        data = urllib.parse.urlencode(dict(client_id=self.client_id, grant_type='authorization_code',
                                           code=code, redirect_uri=REDIRECT, code_verifier=verifier)).encode()
        request = urllib.request.Request(DISCORD_API + '/oauth2/token', data=data,
                                         headers={'Content-Type':'application/x-www-form-urlencoded','User-Agent':'DiscordPS5Companion/10'})
        with urllib.request.urlopen(request, timeout=15) as resp:
            token_data = json.load(resp)
        token = token_data.get('access_token')
        if not isinstance(token, str) or not token:
            raise RuntimeError('Discord returned no access token')
        user_req = urllib.request.Request(DISCORD_API + '/users/@me',
                                          headers={'Authorization':f'Bearer {token}', 'User-Agent':'DiscordPS5Companion/10'})
        with urllib.request.urlopen(user_req, timeout=15) as resp:
            identity = json.load(resp)
        name = identity.get('global_name') or identity.get('username')
        if not isinstance(name, str) or not name.strip():
            raise RuntimeError('Discord identify response has no username')
        try:
            self.report_discord(name)
        except (OSError, urllib.error.URLError) as exc:
            # Discord OAuth itself succeeded but PS5 HTTP can be blocked by its
            # homebrew sandbox. Never claim the PS5 has been linked in this case.
            self.linked_username = name
            print('Discord identity verified on Windows only; PS5 webserver offline:',
                  type(exc).__name__, flush=True)
        return name

    def ps5_request(self, path: str, body: bytes | None = None):
        # Pair only with the user-supplied on-screen code. Cache HttpOnly session.
        with self.ps5_http_lock:
            if self.ps5_cookie is None:
                request = urllib.request.Request(self.ps5_url + '/api/pair',
                    data=self.pairing.encode('ascii'), headers={'Content-Type':'text/plain'})
                with urllib.request.urlopen(request, timeout=1) as response:
                    cookie = response.headers.get('Set-Cookie', '').split(';')[0]
                if not cookie.startswith('ps5_session='):
                    raise RuntimeError('PS5 returned no pairing session')
                self.ps5_cookie = cookie
            request = urllib.request.Request(self.ps5_url + path, data=body,
                headers={'Cookie':self.ps5_cookie, 'Content-Type':'text/plain'})
            try:
                with urllib.request.urlopen(request, timeout=1) as response:
                    return json.load(response)
            except urllib.error.HTTPError as exc:
                if exc.code == 401:
                    self.ps5_cookie = None
                raise

    def report_device_code(self, code, expires):
        payload=(str(expires)+'\n'+code).encode('ascii')
        self.ps5_request('/api/discord/device',payload)

    def ui_status(self):
        result = {'ps5_ip':self.ps5_ip, 'discord_name':self.linked_username,
                  'mode':self.mode, 'audio_rx':self.audio_rx, 'audio_tx':self.audio_tx,
                  'audio_active':time.monotonic()-self.last_audio_at < 3,
                  'ps5_web_available':False, 'device_auth':self.device_auth.snapshot()}
        try:
            result.update(self.ps5_request('/api/status'))
            result['ps5_web_available'] = True
        except (OSError, ValueError, RuntimeError):
            pass
        return result

    def serve_oauth(self):
        companion = self
        class OAuthHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                path = urllib.parse.urlsplit(self.path)
                if path.path == '/login':
                    try:
                        url = companion.oauth_start()
                    except ValueError as e:
                        return self.respond(400, str(e))
                    self.send_response(302)
                    self.send_header('Location', url)
                    self.send_header('Cache-Control', 'no-store')
                    self.send_header('Content-Length', '0')
                    self.end_headers()
                elif path.path == '/status':
                    body = json.dumps(companion.ui_status(),ensure_ascii=False).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type','application/json; charset=utf-8')
                    self.send_header('Cache-Control','no-store')
                    self.send_header('X-Content-Type-Options','nosniff')
                    self.send_header('Content-Length',str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                elif path.path == '/callback':
                    args = urllib.parse.parse_qs(path.query)
                    try:
                        if 'error' in args:
                            raise RuntimeError('Discord verweigert: ' + args['error'][0])
                        name = companion.oauth_callback(args.get('state',[''])[0], args.get('code',[''])[0])
                        self.respond(200, f'Anmeldung erfolgreich: {name}. Du kannst das Fenster schließen.')
                    except Exception as e:
                        self.respond(400, 'Discord Login fehlgeschlagen: ' + str(e))
                elif path.path == '/':
                    body = (Path(__file__).parent/'control_center.html').read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type','text/html; charset=utf-8')
                    self.send_header('Cache-Control','no-store')
                    self.send_header('X-Content-Type-Options','nosniff')
                    self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
                    self.send_header('Content-Length',str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                else:
                    self.respond(404, 'Not Found')
            def do_POST(self):
                # Browser mutations must originate from this loopback UI.
                expected = 'http://127.0.0.1:8765'
                if self.headers.get('Host') != '127.0.0.1:8765' or self.headers.get('Origin') != expected:
                    return self.respond(403, 'Invalid origin')
                if self.path == '/api/discord/device/start':
                    if self.headers.get('Content-Length','0')!='0':
                        return self.respond(400,'Expected empty body')
                    try:
                        companion.device_auth.start()
                        return self.respond(202,'Geräteanmeldung gestartet.')
                    except ValueError as exc:
                        return self.respond(400,str(exc))
                if self.path != '/api/audio/control':
                    return self.respond(404, 'Not Found')
                if self.headers.get('Content-Length') != '5':
                    return self.respond(400, 'Invalid control length')
                self.connection.settimeout(2)
                try:
                    body = self.rfile.read(5)
                    if len(body)!=5 or body[:1] not in (b'0',b'1') or body[1:2] not in (b'0',b'1') or not body[2:].isdigit() or int(body[2:])>100:
                        return self.respond(400, 'Invalid controls')
                    companion.ps5_request('/api/audio/control',body)
                    self.respond(200,'Audio-Einstellung übernommen.')
                except (OSError, ValueError, RuntimeError):
                    self.respond(503,'PS5-Webserver nicht erreichbar. Audio-Einstellung nicht übernommen.')
            def respond(self, status: int, msg: str):
                # Avoid putting arbitrary Discord errors into executable markup.
                import html
                body = ('<!doctype html><meta charset="utf-8"><title>Discord PS5</title>'
                        '<body style="background:#13131b;color:#eee;font:18px sans-serif;padding:40px">'
                        '<h2>DISCORD BY IZZADEEN</h2><p>'+ html.escape(msg) +'</p></body>').encode()
                self.send_response(status)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Cache-Control','no-store')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Length',str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, fmt, *args):
                # No OAuth codes, query or tokens in logs.
                pass
        with http.server.ThreadingHTTPServer(('127.0.0.1', 8765), OAuthHandler) as server:
            print('OAuth callback: ' + REDIRECT, flush=True)
            self.oauth_ready.set()
            server.serve_forever()

    def serve_audio(self):
        # Two simultaneous paths:
        # (1) PS5 can bind UDP 43670: PC sends PV10/echo as before.
        # (2) PS5 explicit bind fails: PS5 broadcasts PV14 from an automatically
        #     allocated UDP socket. PC listens on 43671 and replies to that port.
        sink = None
        if self.mode == 'discord':
            try:
                from v7_audio import DiscordAudio
            except ImportError as e:
                raise RuntimeError('Optional desktop mode requires VB-CABLE and sounddevice, soundcard, numpy') from e
            sink = DiscordAudio(allow_system_mix=not getattr(self,'strict_isolated_audio',False))
            sink.start()
        peer = (self.ps5_ip, AUDIO_PORT)
        silence = bytes(FRAME_BYTES)
        direct = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        discovery = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            direct.bind(('0.0.0.0', 0))
            discovery.bind(('0.0.0.0', 43671))
        except OSError as exc:
            direct.close(); discovery.close()
            if sink: sink.close()
            raise RuntimeError('Windows UDP 43671 nicht verfuegbar; Firewall/Portbelegung pruefen') from exc
        print('LAN voice: direct 43670 + outbound discovery 43671, mode=' + self.mode, flush=True)
        last_hello = 0.0
        last_direct_audio = 0.0
        last_outbound_audio = 0.0
        outbound_peer = None
        try:
            while not self.stop.is_set():
                now = time.monotonic()
                # Re-send direct handshake after a console/PC restart, not just
                # before the first ever PCM packet. A stale connection must recover.
                if now - last_direct_audio > 3.0 and now - last_hello >= 1.0:
                    direct.sendto(b'PV10' + self.pairing.encode('ascii') + b'\r\n', peer)
                    last_hello = now
                if outbound_peer is not None and now - last_outbound_audio > 8.0:
                    outbound_peer = None
                readable, _, _ = select.select([direct, discovery], [], [], 0.25)
                for sock in readable:
                    packet, addr = sock.recvfrom(2048)
                    if addr[0] != self.ps5_ip:
                        continue
                    if sock is discovery and packet == b'PV14' + self.pairing.encode('ascii') + b'\r\n':
                        outbound_peer = addr
                        last_outbound_audio = time.monotonic()
                        discovery.sendto(b'PA14' + self.pairing.encode('ascii') + b'\r\n', addr)
                        print('PS5 outbound discovery paired (no PS5 bind required)', flush=True)
                        continue
                    is_direct = sock is direct and addr[1] == AUDIO_PORT
                    is_outbound = sock is discovery and addr == outbound_peer
                    if not (is_direct or is_outbound) or not packet_valid(packet):
                        continue
                    self.audio_rx += 1
                    self.last_audio_at = time.monotonic()
                    if is_direct:
                        last_direct_audio = time.monotonic()
                    if is_outbound:
                        last_outbound_audio = time.monotonic()
                    seq = struct.unpack_from('<I', packet, 4)[0]
                    samples = packet[8:]
                    if sink is not None:
                        try:
                            samples = sink.on_ps5_audio(samples)
                        except Exception as exc:
                            print('Audioausgabe fehlgeschlagen:', type(exc).__name__, str(exc), flush=True)
                            raise
                    sent = sock.sendto(audio_packet(seq, samples if len(samples) == FRAME_BYTES else silence), addr)
                    if sent == 520:
                        self.audio_tx += 1
                    if self.audio_rx % 200 == 0:
                        print('LAN PCM RX', self.audio_rx, 'TX', self.audio_tx,
                              '(outbound)' if is_outbound else '(direct)', flush=True)
        finally:
            direct.close(); discovery.close()
            if sink:
                sink.close()


def export_bridge_ip(ps5_ip: str, destination=None) -> str:
    """Discover the LAN interface used to reach PS5; never use the PC loopback IP."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        probe.connect((ps5_ip, AUDIO_PORT))
        candidate = probe.getsockname()[0]
    addr = ipaddress.IPv4Address(candidate)
    if not addr.is_private or addr.is_loopback or addr.is_link_local:
        raise ValueError('Keine private lokale Windows-IP fuer PS5 erreichbar')
    output = destination or Path(__file__).resolve().parent / 'bridge_ip.txt'
    output.write_text(str(addr) + '\n', encoding='ascii')
    return str(addr)


def setup_logs():
    """Keep small diagnostic logs without storing secrets, pairing codes or URLs."""
    root = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'DiscordPS5Bridge' / 'logs'
    root.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger('discord_ps5')
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        fh = RotatingFileHandler(root / 'bridge.log', maxBytes=512*1024, backupCount=3, encoding='utf-8')
        fh.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(fh)
    return logger


def main():
    logger = setup_logs()
    logger.info('Discord Bridge gestartet; Version 20 Controller, kein Token-Logging')
    parser = argparse.ArgumentParser(description='Discord PS5 V21 UI PC companion')
    parser.add_argument('--ps5-ip',default='',help='IP on the PS5 screen (not Windows IP)')
    parser.add_argument('--pairing',default='',help='six-digit PS5 on-screen pairing code')
    parser.add_argument('--client-id',default=os.getenv('DISCORD_CLIENT_ID',''),help='Discord Developer App client ID')
    parser.add_argument('--mode',choices=['echo','discord'],default='echo',help='discord uses existing Windows Discord + VB-CABLE')
    parser.add_argument('--strict-isolated-audio',action='store_true',help='use separate existing Windows playback device; no Windows system mix')
    args=parser.parse_args()
    ip = args.ps5_ip or input('PS5-IP eingeben (z. B. 192.0.2.10): ').strip()
    pairing = args.pairing or input('6-stelligen PS5-Kopplungscode eingeben: ').strip()
    cid = args.client_id or input('Discord Client-ID (Enter = OAuth aus): ').strip()
    print('Betriebsart:', 'Discord Desktop Audio Bridge (benoetigt VB-CABLE)' if args.mode == 'discord' else 'Lokaler Echo-Test')
    companion = Companion(ip, pairing, cid, args.mode)
    companion.strict_isolated_audio = args.strict_isolated_audio
    logger.info('PS5-IP=%s Modus=%s', companion.ps5_ip, args.mode)
    try:
        local_ip = export_bridge_ip(companion.ps5_ip)
        print('Windows-PC-IP fuer PS5-Unicast:', local_ip)
        print('Optionale Datei fuer die PS5 erstellt: bridge_ip.txt (neben start_windows.cmd)')
    except (OSError,ValueError) as exc:
        print('HINWEIS: PC-IP-Datei konnte nicht erstellt werden:', type(exc).__name__)
    try:
        with urllib.request.urlopen(companion.ps5_url + '/',timeout=4) as response:
            print('PS5-Webserver HTTP',response.status)
    except (OSError,urllib.error.URLError) as e:
        print('HINWEIS: PS5-Weboberflaeche Port 4747 nicht erreichbar; Audio kann trotzdem funktionieren.')
    thread = threading.Thread(target=companion.serve_oauth,daemon=True)
    thread.start()
    if not companion.oauth_ready.wait(4):
        print('WARNUNG: Lokale Bedienoberflaeche Port 8765 nicht erreichbar.')
    else:
        print('Discord Bedienoberflaeche: http://127.0.0.1:8765/')
        webbrowser.open('http://127.0.0.1:8765/')
    if cid:
        print('Discord OAuth anmelden am WINDOWS-PC: http://127.0.0.1:8765/login')
    else:
        print('Ohne Client-ID bleibt OAuth aus; Audio und Bedienoberflaeche sind verfuegbar.')
    companion.serve_audio()


if __name__ == '__main__':
    main()
