#!/usr/bin/env bash
set -euo pipefail
PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ROOT=${DISCORD_BUILD_ROOT:-"$HOME/ps5-native-app-boilerplate"}
[ -s "$ROOT/Makefile" ] || { echo 'FEHLER: PS5-Boilerplate fehlt. README lesen.';exit 2; }
cd "$ROOT"
APP=tests/discord-v21
mkdir -p "$APP/src" "$APP/sce_sys" "$APP/assets"
python3 "$PACKAGE/tools/run_tests.py"
cp "$PACKAGE/src/"* "$APP/src/"
cp src/demo_renderer.* "$APP/src/"
python3 "$PACKAGE/tools/extend_colors.py" "$APP/src/demo_renderer.hpp"
cp "$PACKAGE/sce_sys/param.json" "$PACKAGE/sce_sys/icon0.png" "$APP/sce_sys/"
# Use the known AudioIn import shim from the user's previously successful build.
bash tools/setup-native-dependencies.sh >/dev/null
SDK=.deps/native/ps5-payload-sdk/target/lib
if [ ! -s "$SDK/libSceAudioIn.so" ]; then
 printf '%s  %s\n' d448220f76cb8ce100143f0d19fb50f124e4256ed90c84f5a7e4e5e2a72fda5c "$PACKAGE/imports/libSceAudioIn.so" | sha256sum -c -
 cp "$PACKAGE/imports/libSceAudioIn.so" "$SDK/libSceAudioIn.so"
fi
for symbol in sceAudioInOpen sceAudioInInput sceAudioInClose; do
 readelf --dyn-syms -W "$SDK/libSceAudioIn.so" | grep -F "$symbol" >/dev/null || { echo "FEHLER: Import fehlt: $symbol";exit 4; }
done
make app APP_SOURCE_DIR="$APP/src" APP_PARAM="$APP/sce_sys/param.json" APP_SCE_SYS="$APP/sce_sys" APP_ASSETS="$APP/assets" APP_DEFINITIONS=V9_HAVE_NETCTL=1 PACBREW_PACKAGES= APP_WRAP_SYMBOLS=
test -s dist/PPSA12360/eboot.bin
echo 'FERTIG: dist/PPSA12360.zip'
if command -v explorer.exe >/dev/null 2>&1;then explorer.exe "$(wslpath -w "$ROOT/dist")" || true;fi
