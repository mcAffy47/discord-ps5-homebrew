#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
assert 'enum class Color' in s and 'yellow = UINT32_C(0xff00ffff),' in s, 'Unexpected renderer header'
assert 'blurple =' not in s, 'Colors already installed'
def abgr(hex_rgb):
 v=int(hex_rgb.lstrip('#'),16)
 return f'UINT32_C(0xff{v&255:02x}{(v>>8)&255:02x}{(v>>16)&255:02x})'
colors={
 'discordBg':'#1e1f22','discordSidebar':'#121318','discordSurface':'#2b2d31',
 'discordRaised':'#313338','discordStroke':'#41434a','blurple':'#5865f2',
 'blurpleDark':'#39439b','discordWhite':'#f2f3f5','discordMuted':'#b5bac1',
 'discordGreen':'#23a559','discordRed':'#f23f43','discordAmber':'#f0b232',
 'discordBubble':'#35385c','discordCool':'#99a1ff'
}
extra=''.join(f'    {k} = {abgr(v)},\n' for k,v in colors.items())
s=s.replace('yellow = UINT32_C(0xff00ffff),','yellow = UINT32_C(0xff00ffff),\n'+extra.rstrip('\n'),1)
p.write_text(s)
print('PASS: PS5-native Discord palette generated')
