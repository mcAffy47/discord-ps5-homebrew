"""Run host checks sequentially: native simulations share loopback ports."""
import json,os,shutil,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
compiler=os.environ.get('CXX') or shutil.which('clang++') or shutil.which('clang++-18')
if not compiler:raise SystemExit('Clang C++ compiler required for host checks.')
results=[]
with tempfile.TemporaryDirectory(prefix='discord-v21-tests-') as temp:
    for path in sorted((root/'tests').glob('test_*.cpp')):
        target=Path(temp)/path.stem
        subprocess.run([compiler,'-std=c++20','-Wall','-Wextra','-Werror','-I',str(root/'src'),str(path),'-o',str(target)],check=True)
        result=subprocess.run([str(target)],capture_output=True,text=True,timeout=30)
        results.append({'test':path.name,'status':'PASS' if result.returncode==0 else 'FAIL','output':result.stdout+result.stderr})
        print(results[-1]['status'],path.name,flush=True)
    for path in sorted((root/'tests').glob('test_*.py')):
        try:
            result=subprocess.run(['python3',str(path)],capture_output=True,text=True,timeout=40)
            results.append({'test':path.name,'status':'PASS' if result.returncode==0 else 'FAIL','output':result.stdout+result.stderr})
        except subprocess.TimeoutExpired:
            results.append({'test':path.name,'status':'FAIL','output':'Timed out'})
        print(results[-1]['status'],path.name,flush=True)
(root/'TEST_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
failed=[r for r in results if r['status']!='PASS']
for result in failed:print(result['test'],result['output'])
raise SystemExit(bool(failed))
