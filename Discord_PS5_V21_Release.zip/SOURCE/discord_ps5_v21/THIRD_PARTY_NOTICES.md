# Source provenance

- PS5 native application boilerplate, renderer, build tools and runtime: BlackBearReloaded, GPL-3.0-or-later. https://github.com/blackbearreloaded/ps5-native-app-boilerplate/tree/b8dc4a3fe2e05e826b037bd68824751c7468a6d7
- `src/ps5_pad.hpp`: BlackBearReloaded, GPL-3.0-or-later. https://github.com/blackbearreloaded/ps5-native-gamepad-input-research/tree/bda3543ab4a070a385e605c9b8981fb4a7faadcd
- Public PS5 payload SDK v0.42: https://github.com/ps5-payload-dev/sdk/releases/tag/v0.42 — build-time dependency; its licenses apply to its components.
- AudioIn import shim: retained from the user's `discord_v3_multitest.zip`; SHA-256 d448220f76cb8ce100143f0d19fb50f124e4256ed90c84f5a7e4e5e2a72fda5c. It supplies linker imports; it is not a bundled Sony runtime module.
- Discord Device Authorization implementation follows https://docs.discord.com/developers/discord-social-sdk/development-guides/account-linking-on-consoles (reviewed 2026-10-12). App access/configuration required. Token acquisition is separate from voice-channel access.

The source in this release, including modifications and the native input integration, is provided under GPL-3.0-or-later; see LICENSE. The compiled app uses platform libraries already on the user's console. Discord and PlayStation names identify interoperability; this is an unofficial homebrew project.
