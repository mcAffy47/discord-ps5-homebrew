#pragma once
#include <array>
#include <cstdint>
#include <cstring>
namespace discord_v9 {
// Self-contained QR Model 2 version 3, EC level M, mask 0, byte mode.
// Max 42 byte URL. No network request, no third-party renderer.
struct LocalQR {
 static constexpr int n=29;
 bool dark[n][n]{};
 bool fixed[n][n]{};
 void set(int x,int y,bool v){if(x>=0 && y>=0 && x<n && y<n){dark[y][x]=v;fixed[y][x]=true;}}
 static unsigned mul(unsigned x,unsigned y){unsigned z=0;for(int i=0;i<8;++i){if(y&1)z^=x;y>>=1;x<<=1;if(x&0x100)x^=0x11D;}return z;}
 static std::array<std::uint8_t,26> ecc(const std::array<std::uint8_t,44>&data){
    std::array<unsigned,27> gen{};gen[0]=1;int degree=0,root=1;
    for(int r=0;r<26;++r){
      std::array<unsigned,27> next{};
      for(int k=0;k<=degree;++k){next[k]^=gen[k];next[k+1]^=mul(gen[k],root);}
      gen=next;++degree;root=mul(root,2);
    }
    std::array<std::uint8_t,26> rem{};
    for(auto v:data){const unsigned f=unsigned(v)^rem[0];
       for(int i=0;i<25;++i)rem[i]=static_cast<std::uint8_t>(rem[i+1]^mul(gen[i+1],f));
       rem[25]=static_cast<std::uint8_t>(mul(gen[26],f));
    }return rem;
 }
 void finder(int x,int y){for(int dy=-1;dy<=7;++dy)for(int dx=-1;dx<=7;++dx){int a=dx,b=dy;
   bool black=a>=0 && a<7 && b>=0 && b<7 && (a==0||a==6||b==0||b==6||(a>=2&&a<=4&&b>=2&&b<=4));set(x+dx,y+dy,black);
 }}
 void format(){
   // QR error correction M (00), fixed mask 0 (000), 15-bit BCH.
   const unsigned data=0;
   unsigned rem=data;
   for(int i=0;i<10;++i)rem=(rem<<1)^((rem>>9)*0x537U);
   const unsigned bits=((data<<10)|rem)^0x5412U;
   auto bit=[&](int i){return ((bits>>i)&1U)!=0U;};
   for(int i=0;i<=5;++i)set(8,i,bit(i));
   set(8,7,bit(6));set(8,8,bit(7));set(7,8,bit(8));
   for(int i=9;i<15;++i)set(14-i,8,bit(i));
   for(int i=0;i<8;++i)set(n-1-i,8,bit(i));
   for(int i=8;i<15;++i)set(8,n-15+i,bit(i));
   set(8,n-8,true);
 }
 bool encode(const char*str){
    const std::size_t len=std::strlen(str);
    if(len>42)return false;
    std::array<std::uint8_t,44> data{};
    int pos=0;
    auto append=[&](unsigned value,int bits){for(int j=bits-1;j>=0;--j){if(pos>=352)return false;if((value>>j)&1U)data[pos/8]|=static_cast<std::uint8_t>(1U<<(7-pos%8));++pos;}return true;};
    if(!append(4,4)||!append(static_cast<unsigned>(len),8))return false;
    for(std::size_t i=0;i<len;++i)if(!append(static_cast<unsigned char>(str[i]),8))return false;
    for(int i=0;i<4 && pos<352;++i)append(0,1);
    while(pos%8)append(0,1);
    for(int p=pos/8;p<44;++p)data[p]=static_cast<std::uint8_t>(p%2==pos/8%2?0x11:0xEC);
    const auto check=ecc(data);
    std::array<std::uint8_t,70> full{};
    for(int i=0;i<44;++i)full[i]=data[i];
    for(int i=0;i<26;++i)full[44+i]=check[i];
    finder(0,0);finder(n-7,0);finder(0,n-7);
    for(int i=8;i<n-8;++i){set(i,6,i%2==0);set(6,i,i%2==0);}
    for(int dy=-2;dy<=2;++dy)for(int dx=-2;dx<=2;++dx){int mx=dx<0?-dx:dx,my=dy<0?-dy:dy;set(22+dx,22+dy,mx==2||my==2||(mx==0&&my==0));}
    format();
    int consumed=0;
    for(int right=n-1;right>=1;right-=2){
       if(right==6)--right;
       for(int vert=0;vert<n;++vert){const int y=(((right+1)&2)==0)? n-1-vert:vert;
          for(int dx=0;dx<2;++dx){const int x=right-dx;
             if(fixed[y][x])continue;
             bool black=false;
             if(consumed<560)black=((full[consumed/8]>>(7-consumed%8))&1U)!=0;
             ++consumed;
             dark[y][x]=black^(((x+y)%2)==0);
          }
       }
    }
    return consumed>=560;
 }
};
}
