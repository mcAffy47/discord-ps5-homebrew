#pragma once
#include <cstdint>
namespace lanvoice {
// Lightweight loss/duplicate guard. Large forward sequence jumps are allowed
// with a gap count; delayed/out-of-order frames are dropped (no reorder buffer).
struct RxSequence {
 bool started=false;
 std::uint32_t expected=0, gaps=0, rejected=0;
 void reset() noexcept {started=false;expected=0;}
 bool accept(std::uint32_t seq) noexcept {
   if(!started){started=true;expected=seq+1U;return true;}
   const std::uint32_t ahead=seq-expected;
   if(ahead>=0x80000000U){++rejected;return false;}
   if(ahead>0){gaps+=ahead;}
   expected=seq+1U;
   return true;
 }
};
}
