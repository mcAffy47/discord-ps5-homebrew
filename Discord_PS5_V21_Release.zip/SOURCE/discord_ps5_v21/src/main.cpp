/*
 * Discord PS5 V21 VOICE UI BETA - integrated LAN dashboard, audio and identity (independent from PS5 Discord voice auth).
 * IMPORTANT: This source intentionally DOES NOT use undocumented Discord user
 * voice gateways, collect Discord tokens, or claim voice-channel connectivity.
 * Designed for standalone PS5 native-homebrew build with demo_renderer.
 */
#include "demo_renderer.hpp"
#include "http_protocol.hpp"
#include "dashboard.hpp"
#include "qr_v3.hpp"
#include "lan_protocol.hpp"
#include "rx_sequence.hpp"
#include "controller_ui.hpp"
#include <array>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <pthread.h>
#include <unistd.h>

extern "C" {
 #ifdef V9_HAVE_NETCTL
 int sceNetCtlInit(void);
 #endif
 int sceNetInit(void);
 int sceNetPoolCreate(const char*,int,int);
 int sceNetSocket(const char*,int,int,int);
 int sceNetBind(int,const void*,unsigned);
 int sceNetListen(int,int);
 int sceNetAccept(int,void*,unsigned*);
 int sceNetConnect(int,const void*,unsigned);
 int sceNetGetsockname(int,void*,unsigned*);
 int sceNetSend(int,const void*,unsigned,int);
 int sceNetRecv(int,void*,unsigned,int);
 int sceNetSocketClose(int);
 int sceNetSetsockopt(int,int,int,const void*,unsigned);
 int sceNetInetPton(int,const char*,void*);
 int sceNetRecvfrom(int,void*,unsigned,int,void*,unsigned*);
 int sceNetSendto(int,const void*,unsigned,int,const void*,unsigned);
 int sceUserServiceInitialize(void*);
 int sceUserServiceGetInitialUser(int*);
 int sceAudioInOpen(int,int,int,unsigned,unsigned,unsigned);
 int sceAudioInInput(int,void*);
 int sceAudioInClose(int);
 int sceAudioOutInit(void);
 int sceAudioOutOpen(int,int,int,unsigned,unsigned,unsigned);
 int sceAudioOutOutput(int,const void*);
 int sceAudioOutClose(int);
 unsigned short sceNetHtons(unsigned short);
}
namespace {
struct Sock4 {std::uint8_t len,family;std::uint16_t port;std::uint8_t ip[4],pad[8];};
static_assert(sizeof(Sock4)==16,"PS5 sockaddr length mismatch");
constexpr int kInet=2,kUdp=2,kTcp=1,kPort=4747,kAudioPort=43670,kDiscoverPort=43671,kNonBlock=0x80;
// Tentative diagnostic values only: do not infer firmware-specific meaning.
constexpr std::uint32_t kAdhoc=0x804101A0U,kAddressInUse=0x80410130U;
std::atomic<int> stage{0},netctl_result{0},net_result{0},pool_result{0},socket_result{0},bind_result{0},listen_result{0};
std::atomic<int> connections{0},requests{0},retries{0},pair_failures{0};
discord_v9::LocalQR local_qr;
std::atomic<bool> qr_ready{false},auth_ready{false},ip_ready{false},net_started{false};
char ip[28]="NOT FOUND";
char token[33]{};
char pair_code[7]{};
char discord_name[40]{};
char device_code[33]{};
std::time_t device_expires=0;
discord_v9::LocalQR device_qr;
pthread_mutex_t device_lock=PTHREAD_MUTEX_INITIALIZER;
std::atomic<int> discord_linked{0};
std::atomic<int> audio_user{-1},audio_mic_err{0},audio_out_err{0},audio_net_err{0},audio_stage{0};
std::atomic<int> audio_sent{0},audio_recv{0},audio_played{0},audio_peak{0},audio_peer{0};
std::atomic<int> audio_seq_gaps{0},audio_seq_rejected{0},audio_reconnects{0};
std::atomic<int> outbound_stage{0},outbound_error{0},outbound_beacons{0};
std::atomic<int> udp_bind_err{0},bind_probe_http{0},bind_probe_udp{0},tcp_bind_mode{-1},udp_bind_mode{-1},tcp_bind_attempts{0},udp_bind_attempts{0};
std::atomic<int> mic_muted{0},headset_muted{0},headset_volume{100};
pthread_mutex_t name_lock=PTHREAD_MUTEX_INITIALIZER;
struct AudioQueue {
 std::int16_t data[12][lanvoice::kFrames]{}; int head=0,tail=0,count=0;
 pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
 void push(const std::int16_t *p){pthread_mutex_lock(&lock);if(count==12){head=(head+1)%12;--count;}std::memcpy(data[tail],p,sizeof(data[tail]));tail=(tail+1)%12;++count;pthread_mutex_unlock(&lock);}
 bool pop(std::int16_t *p){pthread_mutex_lock(&lock);const bool yes=count>0;if(yes){std::memcpy(p,data[head],sizeof(data[head]));head=(head+1)%12;--count;}pthread_mutex_unlock(&lock);return yes;}
 void flush(){pthread_mutex_lock(&lock);head=tail=count=0;pthread_mutex_unlock(&lock);}
} audio_queue;
pthread_mutex_t auth_lock=PTHREAD_MUTEX_INITIALIZER;
std::time_t failure_window=0;
int failures=0;

bool secure_random(void*buf,std::size_t n){
 FILE* f=std::fopen("/dev/urandom","rb");
 if(!f)return false;
 const auto got=std::fread(buf,1,n,f);
 std::fclose(f);
 return got==n;
}
char hex_digit(unsigned x){return "0123456789abcdef"[x&15U];}
bool setup_auth(){
 unsigned char random[20]{};
 if(!secure_random(random,sizeof(random)))return false;
 for(int i=0;i<16;++i){token[2*i]=hex_digit(random[i]>>4);token[2*i+1]=hex_digit(random[i]);}
 const std::uint32_t n=(std::uint32_t(random[16])<<24)|(std::uint32_t(random[17])<<16)|(std::uint32_t(random[18])<<8)|random[19];
 std::snprintf(pair_code,sizeof(pair_code),"%06u",n%1000000U);
 return true;
}
void identify_ip(){
 const int fd=sceNetSocket("discord_route_ip",kInet,kUdp,0);
 if(fd<0)return;
 Sock4 dest{};dest.len=sizeof(dest);dest.family=kInet;dest.port=sceNetHtons(53);
 if(sceNetInetPton(kInet,"1.1.1.1",dest.ip)>0 && sceNetConnect(fd,&dest,sizeof(dest))>=0){
   Sock4 src{};unsigned n=sizeof(src);
   if(sceNetGetsockname(fd,&src,&n)>=0 && n>=8 && (src.ip[0]|src.ip[1]|src.ip[2]|src.ip[3])){
      std::snprintf(ip,sizeof(ip),"%u.%u.%u.%u",src.ip[0],src.ip[1],src.ip[2],src.ip[3]);
      ip_ready.store(true,std::memory_order_release);
   }
 }
 sceNetSocketClose(fd);
}
// One socket per bind attempt. Retry both documented IPv4 layouts only after
// explicitly recording each failure; different sockaddr lengths are sometimes
// treated differently by console firmware/SDK versions. This is a compatibility
// fallback, NOT a promise that a process is allowed to listen in its sandbox.
struct BindResult {int fd=-1;int result=-1;int mode=-1;int tried=0;};
BindResult bind_listener(const char*name,int protocol,unsigned short port){
 BindResult result{};
 for(int option=0;option<4;++option){
   const bool use_ip=(option%2)==0 && ip_ready.load(std::memory_order_acquire);
   if((option%2)==0 && !use_ip)continue;
   const int fd=sceNetSocket(name,kInet,protocol,0);
   if(fd<0){result.result=fd;result.mode=option;break;}
   const int reuse=1;
   sceNetSetsockopt(fd,0xFFFF,0x0004,&reuse,sizeof(reuse));
   Sock4 addr{};
   addr.len=option<2?sizeof(addr):0;
   addr.family=kInet;
   addr.port=sceNetHtons(port);
   if(use_ip && sceNetInetPton(kInet,ip,addr.ip)!=1){sceNetSocketClose(fd);continue;}
   const int rc=sceNetBind(fd,&addr,sizeof(addr));
   ++result.tried;
   result.result=rc;result.mode=option;
   if(rc>=0){result.fd=fd;return result;}
   sceNetSocketClose(fd);
   // Never mask an unknown failure as success. A later error remains visible.
 }
 return result;
}

// Diagnose bind(0): distinguishes unavailable requested port from an
// underlying prohibition of listener/UDP binds. No security bypass.
int ephemeral_bind_probe(const char *name,int kind){
 const int s=sceNetSocket(name,kInet,kind,0);
 if(s<0)return s;
 Sock4 any{};any.len=sizeof(any);any.family=kInet;any.port=0;
 const int rc=sceNetBind(s,&any,sizeof(any));
 sceNetSocketClose(s);
 return rc;
}

void send_all(int fd,const char *buf,std::size_t n){
 while(n){const unsigned take=static_cast<unsigned>(n>4096?4096:n);const int r=sceNetSend(fd,buf,take,0);if(r<=0)break;buf+=r;n-=static_cast<std::size_t>(r);}
}
void reply(int fd,int status,const char* body,const char* ct,const char* cookie=nullptr){
 if(!body)body="";
 const char *status_text=status==200?"200 OK":status==204?"204 No Content":status==400?"400 Bad Request":status==401?"401 Unauthorized":status==403?"403 Forbidden":status==404?"404 Not Found":"503 Service Unavailable";
 char head[1024]{};
 const int count=std::snprintf(head,sizeof(head),"HTTP/1.1 %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\nContent-Security-Policy: default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'\r\nReferrer-Policy: no-referrer\r\n%sConnection: close\r\n\r\n",status_text,ct,std::strlen(body),cookie?cookie:"");
 if(count>0 && static_cast<std::size_t>(count)<sizeof(head)){
  send_all(fd,head,static_cast<std::size_t>(count));send_all(fd,body,std::strlen(body));
 }
}
void handle_client(int fd){
 char reqbuf[2048]{};std::size_t total=0;
 // A bounded request buffer; accept short split header/body reads.
 while(total<sizeof(reqbuf)-1){
   const int n=sceNetRecv(fd,reqbuf+total,static_cast<unsigned>(sizeof(reqbuf)-1-total),0);
   if(n<=0)return;
   total+=static_cast<std::size_t>(n);reqbuf[total]=0;
   if(std::strstr(reqbuf,"\r\n\r\n"))break;
 }
 if(total>=sizeof(reqbuf)-1){reply(fd,400,"Oversized request","text/plain");return;}
 const auto r=discord_v9::parse_request(reqbuf,total);
 if(!r.valid){reply(fd,400,"Bad request","text/plain");return;}
 const char* hdrend=std::strstr(reqbuf,"\r\n\r\n");
 if(!hdrend){reply(fd,400,"Bad request","text/plain");return;}
 ++requests;
 if(discord_v9::same(r.method,"GET") && discord_v9::same(r.path,"/")){
   reply(fd,200,discord_v9::kDashboard,"text/html; charset=utf-8");return;
 }
 if(discord_v9::same(r.method,"POST") && discord_v9::same(r.path,"/api/pair")){
   const char* len=std::strstr(reqbuf,"Content-Length:");
   if(!len || len>hdrend){reply(fd,400,"Missing body size","text/plain");return;}
   unsigned declared=0;
   if(std::sscanf(len,"Content-Length: %u",&declared)!=1 || declared!=6){reply(fd,400,"Expected 6 digits","text/plain");return;}
   const char* body=hdrend+4;
   while(total<static_cast<std::size_t>((hdrend+4)-reqbuf)+6 && total<sizeof(reqbuf)-1){
     const int n=sceNetRecv(fd,reqbuf+total,static_cast<unsigned>(sizeof(reqbuf)-1-total),0);
     if(n<=0)break;
     total+=static_cast<std::size_t>(n);reqbuf[total]=0;
   }
   if(total<static_cast<std::size_t>(body-reqbuf)+6){reply(fd,400,"Incomplete body","text/plain");return;}
   bool match=false,locked=false;
   pthread_mutex_lock(&auth_lock);
   const std::time_t now=std::time(nullptr);
   if(now>0 && (failure_window==0 || now<failure_window || now-failure_window>60)){
      failure_window=now;failures=0;
   }
   locked=failures>=5;
   if(!locked && std::memcmp(body,pair_code,6)==0) {match=true;failures=0;}
   else {++failures;++pair_failures;}
   pthread_mutex_unlock(&auth_lock);
   if(!match){reply(fd,403,locked?"Too many tries; wait 60 seconds":"Invalid pairing code","text/plain");return;}
   char cookie[140]{};
   std::snprintf(cookie,sizeof(cookie),"Set-Cookie: ps5_session=%s; HttpOnly; SameSite=Strict; Path=/\r\n",token);
   reply(fd,200,"{\"paired\":true}","application/json",cookie);return;
 }
 if(discord_v9::same(r.method,"POST") && discord_v9::same(r.path,"/api/discord/result")){
   // Trusted home-network PC companion reports verified OAuth /users/@me identity.
   // No Discord access token is ever sent to or stored on the PS5.
   const char* body=hdrend+4;
   std::size_t have=total-static_cast<std::size_t>(body-reqbuf);
   unsigned declared=0;const char* len=std::strstr(reqbuf,"Content-Length:");
   if(!len || len>=hdrend || std::sscanf(len,"Content-Length: %u",&declared)!=1 || declared<8 || declared>60){reply(fd,400,"Bad length","text/plain");return;}
   while(have<declared && total<sizeof(reqbuf)-1){
       const int n=sceNetRecv(fd,reqbuf+total,static_cast<unsigned>(sizeof(reqbuf)-1-total),0);
       if(n<=0)break;
       total+=static_cast<std::size_t>(n);reqbuf[total]=0;
       have=total-static_cast<std::size_t>(body-reqbuf);
   }
   if(have!=declared){reply(fd,400,"Bad payload","text/plain");return;}
   char supplied[7]{};std::memcpy(supplied,body,6);
   bool allowed=false;
   pthread_mutex_lock(&auth_lock);
   const std::time_t now=std::time(nullptr);
   if(now>0 && (failure_window==0 || now<failure_window || now-failure_window>60)){
      failure_window=now;failures=0;
   }
   if(failures<5 && std::memcmp(supplied,pair_code,6)==0 && body[6]=='\n'){
      allowed=true;failures=0;
   }else{++failures;++pair_failures;}
   pthread_mutex_unlock(&auth_lock);
   if(!allowed){reply(fd,403,"Pair first or wait 60 seconds","text/plain");return;}
   char name[40]{};std::size_t i=0;
   for(const char* cur=body+7;cur<reqbuf+total && i<sizeof(name)-1;++cur){
     const unsigned char x=static_cast<unsigned char>(*cur);
     if(x=='\n'||x=='\r')break;
     name[i++]=(x>=32 && x<127 && x!='"' && x!='\\')?char(x):'_';
   }
   if(i==0){reply(fd,400,"Empty username","text/plain");return;}
   pthread_mutex_lock(&name_lock);std::memcpy(discord_name,name,sizeof(name));pthread_mutex_unlock(&name_lock);
   discord_linked.store(1);
   reply(fd,200,"{\"received\":true}","application/json");return;
 }
 if(discord_v9::same(r.method,"POST") && discord_v9::same(r.path,"/api/discord/device")){
   if(!discord_v9::token_from_cookie(reqbuf,total,token)){reply(fd,401,"Pairing required","text/plain");return;}
   const char* len=std::strstr(reqbuf,"Content-Length:");unsigned declared=0;
   if(!len || len>=hdrend || std::sscanf(len,"Content-Length: %u",&declared)!=1 || declared<2 || declared>38){reply(fd,400,"Invalid length","text/plain");return;}
   const char* body=hdrend+4;
   while(total<static_cast<std::size_t>(body-reqbuf)+declared && total<sizeof(reqbuf)-1){
     const int n=sceNetRecv(fd,reqbuf+total,static_cast<unsigned>(sizeof(reqbuf)-1-total),0);
     if(n<=0)break;
     total+=static_cast<std::size_t>(n);reqbuf[total]=0;
   }
   if(total!=static_cast<std::size_t>(body-reqbuf)+declared){reply(fd,400,"Incomplete code","text/plain");return;}
   const char* newline=static_cast<const char*>(std::memchr(body,'\n',declared));
   if(!newline || newline==body || newline-body>4){reply(fd,400,"Invalid expiry","text/plain");return;}
   unsigned ttl=0;
   for(const char*q=body;q<newline;++q){if(*q<'0'||*q>'9'){reply(fd,400,"Invalid expiry","text/plain");return;}ttl=ttl*10+unsigned(*q-'0');}
   const std::size_t length=declared-static_cast<std::size_t>(newline+1-body);
   if(ttl>3600 || length>32 || (ttl>0 && length<4) || (ttl==0 && length!=0)){reply(fd,400,"Invalid code","text/plain");return;}
   for(std::size_t i=0;i<length;++i){const char ch=newline[1+i];if(!((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')||ch=='-')){reply(fd,400,"Invalid code","text/plain");return;}}
   pthread_mutex_lock(&device_lock);
   std::memset(device_code,0,sizeof(device_code));std::memcpy(device_code,newline+1,length);
   device_expires=ttl?std::time(nullptr)+ttl:0;
   // The QR opens Discord's real activation screen; enter the adjacent code.
   device_qr.encode("https://discord.com/activate");
   pthread_mutex_unlock(&device_lock);
   reply(fd,200,"{\"received\":true}","application/json");return;
 }
 if(discord_v9::same(r.method,"POST") && discord_v9::same(r.path,"/api/audio/control")){
   if(!discord_v9::token_from_cookie(reqbuf,total,token)){
     reply(fd,401,"Pairing required","text/plain");return;
   }
   const char* len=std::strstr(reqbuf,"Content-Length:");unsigned declared=0;
   if(!len || len>=hdrend || std::sscanf(len,"Content-Length: %u",&declared)!=1 || declared!=5){reply(fd,400,"Expected M,D,VVV","text/plain");return;}
   const char* body=hdrend+4;
   while(total<static_cast<std::size_t>(body-reqbuf)+5 && total<sizeof(reqbuf)-1){
     const int n=sceNetRecv(fd,reqbuf+total,static_cast<unsigned>(sizeof(reqbuf)-1-total),0);
     if(n<=0)break;
     total+=static_cast<std::size_t>(n);reqbuf[total]=0;
   }
   if(total!=static_cast<std::size_t>(body-reqbuf)+5 || (body[0]!='0' && body[0]!='1') || (body[1]!='0' && body[1]!='1') || body[2]<'0' || body[2]>'9' || body[3]<'0' || body[3]>'9' || body[4]<'0' || body[4]>'9'){
     reply(fd,400,"Invalid controls","text/plain");return;
   }
   const int volume=(body[2]-'0')*100+(body[3]-'0')*10+body[4]-'0';
   if(volume>100){reply(fd,400,"Volume out of range","text/plain");return;}
   mic_muted.store(body[0]-'0');headset_muted.store(body[1]-'0');headset_volume.store(volume);
   reply(fd,200,"{\"applied\":true}","application/json");return;
 }
 if(discord_v9::same(r.method,"GET") && discord_v9::same(r.path,"/api/status")){
   if(!discord_v9::token_from_cookie(reqbuf,total,token)){
     reply(fd,401,"{\"error\":\"pairing_required\"}","application/json");return;
   }
   char name[40]{};
   pthread_mutex_lock(&name_lock);std::memcpy(name,discord_name,sizeof(name));pthread_mutex_unlock(&name_lock);
   char body[1536]{};
   std::snprintf(body,sizeof(body),"{\"version\":\"V21 VOICE UI BETA\",\"web\":\"online\",\"mic_muted\":%d,\"headset_muted\":%d,\"headset_volume\":%d,\"connections\":%d,\"requests\":%d,\"audio_stage\":%d,\"audio_sent\":%d,\"audio_received\":%d,\"audio_lost_packets\":%d,\"audio_duplicate_or_late\":%d,\"audio_played\":%d,\"audio_peak\":%d,\"audio_peer\":%d,\"audio_reconnects\":%d,\"discord_linked\":%s,\"discord_username\":\"%s\",\"discord_voice\":\"not_integrated\",\"server_stage\":%d,\"netctl_error\":%d,\"net_error\":%d,\"tcp_bind_error\":%d,\"udp_bind_error\":%d,\"mic_error\":%d,\"speaker_error\":%d,\"audio_net_error\":%d,\"tcp_bind_mode\":%d,\"udp_bind_mode\":%d,\"tcp_attempts\":%d,\"udp_attempts\":%d,\"probe_tcp\":%d,\"probe_udp\":%d,\"outbound_stage\":%d,\"outbound_error\":%d,\"outbound_beacons\":%d}",mic_muted.load(),headset_muted.load(),headset_volume.load(),connections.load(),requests.load(),audio_stage.load(),audio_sent.load(),audio_recv.load(),audio_seq_gaps.load(),audio_seq_rejected.load(),audio_played.load(),audio_peak.load(),audio_peer.load(),audio_reconnects.load(),discord_linked.load()?"true":"false",name,stage.load(),netctl_result.load(),net_result.load(),bind_result.load(),udp_bind_err.load(),audio_mic_err.load(),audio_out_err.load(),audio_net_err.load(),tcp_bind_mode.load(),udp_bind_mode.load(),tcp_bind_attempts.load(),udp_bind_attempts.load(),bind_probe_http.load(),bind_probe_udp.load(),outbound_stage.load(),outbound_error.load(),outbound_beacons.load());
   reply(fd,200,body,"application/json");return;
 }
 reply(fd,404,"Not found","text/plain");
}
// Retry: useful for loader transitions and boot-time network availability.
void *server_worker(void*){
  if(!setup_auth()){stage.store(-7);return nullptr;}
  auth_ready.store(true,std::memory_order_release);
 #ifdef V9_HAVE_NETCTL
  const int ctl=sceNetCtlInit();netctl_result.store(ctl);
 #else
  netctl_result.store(-10); // SDK lacks SceNetCtl import; compatibility fallback
 #endif
  const int ni=sceNetInit();net_result.store(ni);
  if(ni<0 && static_cast<std::uint32_t>(ni)!=0x804101CAU){stage.store(-10);return nullptr;}
  const int pool=sceNetPoolCreate("discord_v13_network",1024*1024,0);pool_result.store(pool);
  if(pool<0){stage.store(-1);return nullptr;}
  net_started.store(true,std::memory_order_release);
  // Wait for Wi-Fi association before constructing the displayed QR URL.
  for(int ip_attempt=0;ip_attempt<15 && !ip_ready.load();++ip_attempt){
    identify_ip();if(!ip_ready.load())sleep(1);
  }
  if(ip_ready.load(std::memory_order_acquire)){
    char url[80]{};std::snprintf(url,sizeof(url),"http://%s:%d",ip,kPort);
    if(local_qr.encode(url))qr_ready.store(true,std::memory_order_release);
  }
  for(int attempt=0;;++attempt){
    retries.store(attempt);
    if(!ip_ready.load(std::memory_order_acquire)){
       identify_ip();
       if(ip_ready.load()){
         char url[80]{};std::snprintf(url,sizeof(url),"http://%s:%d",ip,kPort);
         if(local_qr.encode(url))qr_ready.store(true);
       }
    }
    BindResult br=bind_listener("discord_v13_http",kTcp,kPort);
    socket_result.store(br.fd);
    bind_result.store(br.result);
    tcp_bind_mode.store(br.mode);
    tcp_bind_attempts.fetch_add(br.tried);
    if(br.fd<0){
      if(attempt==0)bind_probe_http.store(ephemeral_bind_probe("discord_tcp_probe",kTcp));
      stage.store(static_cast<std::uint32_t>(br.result)==kAdhoc?-8:
                  static_cast<std::uint32_t>(br.result)==kAddressInUse?-9:-3);
      sleep(attempt<2?2:25);continue;
    }
    const int fd=br.fd;
    const int lis=sceNetListen(fd,8);listen_result.store(lis);
    if(lis<0){stage.store(-4);sceNetSocketClose(fd);sleep(3);continue;}
    stage.store(1);
    while(true){Sock4 peer{};unsigned len=sizeof(peer);
      const int client=sceNetAccept(fd,&peer,&len);
      if(client<0){stage.store(-5);break;}
      struct {int sec;int usec;} timeout{4,0};
      sceNetSetsockopt(client,0xFFFF,0x1006,&timeout,sizeof(timeout));
      ++connections;handle_client(client);sceNetSocketClose(client);
    }
    sceNetSocketClose(fd);sleep(3);
  }
  return nullptr;
}

// PC -> PS5: sends a short HELLO plus the on-screen pairing code to UDP 43670.
// PS5 discovers the peer address automatically: no PC-IP in the binary.
void* audio_playback(void*){
 // Local speaker tone can be tested even before LAN pairing.
 const int user=audio_user.load();
 const int init=sceAudioOutInit();if(init<0){audio_out_err.store(init);return nullptr;}
 int out=sceAudioOutOpen(user,2,0,256,48000,1);
 if(out<0){audio_out_err.store(out);return nullptr;}
 std::array<std::int16_t,512> stereo{};
 std::array<std::int16_t,256> pcm{};
 unsigned startup_frame=0;
 while(true){
    if(!audio_queue.pop(pcm.data())) pcm.fill(0);
    // One 16 kHz mono frame (256 samples) becomes 768 48 kHz stereo frames.
    // Use nearest-neighbour sample tripling instead of repeating entire chunks.
    for(int block=0;block<3;++block){
      for(int i=0;i<256;++i){
        const int source=(block*256+i)/3;
        std::int16_t sample=pcm[source];
        // Self-check sound: two gentle bursts after the authenticated PC joins.
        // This proves the actual VOICE output path even with a silent mic.
        if(startup_frame<24000U){
          const unsigned t=startup_frame;
          if((t<5500U)||(t>=11500U&&t<17000U)){
            const unsigned phase=(t*440U)%48000U;
            const int triangle=phase<12000U?int(phase):phase<36000U?24000-int(phase):int(phase)-48000;
            sample=static_cast<std::int16_t>(sample+triangle/20);
          }
          ++startup_frame;
        }
        sample=headset_muted.load()?0:static_cast<std::int16_t>(int(sample)*headset_volume.load()/100);
        stereo[2*i]=sample;stereo[2*i+1]=sample;
      }
      const int err=sceAudioOutOutput(out,stereo.data());
      if(err<0){audio_out_err.store(err);sceAudioOutClose(out);return nullptr;}
      audio_played.fetch_add(1);
    }
 }
}
// Optional known Windows Bridge IPv4: avoids mandatory broadcast discovery.
// Configure /data/homebrew/PPSA12360/bridge_ip.txt with ONE private LAN IP.
// No PS5 system files are changed. If unavailable, broadcast remains a fallback.
bool parse_private_ipv4(const char* text, char* destination, std::size_t capacity, bool host_fixture=false){
 unsigned a=0,b=0,c=0,d=0;char junk=0;
 if(std::sscanf(text," %u.%u.%u.%u %c",&a,&b,&c,&d,&junk)!=4 ||
    a>255 || b>255 || c>255 || d>255)return false;
 const bool private_ip=(a==10)||(a==172 && b>=16 && b<=31)||(a==192 && b==168);
 const bool test_loopback=host_fixture && a==127;
 if(!private_ip && !test_loopback)return false;
 const int n=std::snprintf(destination,capacity,"%u.%u.%u.%u",a,b,c,d);
 return n>0 && static_cast<std::size_t>(n)<capacity;
}
bool load_known_pc_ip(char (&pc_ip)[24]){
 // Test-only override; file-based config is used on actual PS5 hardware.
 const char* override_ip=std::getenv("DISCORD_BRIDGE_IP");
 if(override_ip && parse_private_ipv4(override_ip,pc_ip,sizeof(pc_ip),true))return true;
 FILE* f=std::fopen("/data/homebrew/PPSA12360/bridge_ip.txt","rb");
 if(!f)return false;
 char raw[80]{};const std::size_t n=std::fread(raw,1,sizeof(raw)-1,f);std::fclose(f);
 return n>0 && parse_private_ipv4(raw,pc_ip,sizeof(pc_ip));
}
// Experimental outbound-first path: a UDP socket may auto-bind on sendto even
// when explicit sceNetBind() is prohibited for this homebrew's sandbox.
// The Windows helper listens on 43671. PS5 broadcasts only on its own LAN;
// PSN, DNS, Cloudflare and router port forwarding are not involved.
// The 6-digit LAN pairing code is sent in cleartext: private Wi-Fi only.
void outbound_audio_fallback(int mic){
  outbound_stage.store(1);
  int sock=sceNetSocket("discord_v14_outbound",kInet,kUdp,0);
  if(sock<0){outbound_error.store(sock);outbound_stage.store(-1);return;}
  const int yes=1;
  // FreeBSD / PlayStation SO_BROADCAST = 0x20, SOL_SOCKET = 0xFFFF.
  char configured_ip[24]{};
  const bool has_unicast=load_known_pc_ip(configured_ip);
  Sock4 pc{};pc.len=sizeof(pc);pc.family=kInet;pc.port=sceNetHtons(kDiscoverPort);
  if(has_unicast && sceNetInetPton(kInet,configured_ip,pc.ip)!=1){
    outbound_stage.store(-3);sceNetSocketClose(sock);return;
  }
  // Broadcast is optional. Unicast must work even when SO_BROADCAST is denied.
  bool broadcast_enabled=sceNetSetsockopt(sock,0xFFFF,0x0020,&yes,sizeof(yes))>=0;
  Sock4 broadcast{};broadcast.len=sizeof(broadcast);broadcast.family=kInet;
  broadcast.port=sceNetHtons(kDiscoverPort);
  if(sceNetInetPton(kInet,"255.255.255.255",broadcast.ip)!=1)broadcast_enabled=false;
  if(!broadcast_enabled && !has_unicast){outbound_stage.store(-2);sceNetSocketClose(sock);return;}
  std::array<std::int16_t,lanvoice::kFrames> pcm{},received{};
  std::array<unsigned char,lanvoice::kPacketSize> tx{},rx{};
  std::uint32_t seq=0,frames=0;
  lanvoice::RxSequence receive_sequence{};
  bool connected=false;
  std::uint32_t last_rx_frame=0;
  while(true){
    // If the Windows companion is closed/restarted, UDP sends may still
    // succeed silently. Recreate the socket to enable fresh discovery.
    if(connected && frames-last_rx_frame>375U){
      sceNetSocketClose(sock);
      sock=sceNetSocket("discord_v14_reconnect",kInet,kUdp,0);
      if(sock<0){outbound_error.store(sock);outbound_stage.store(-4);break;}
      broadcast_enabled=sceNetSetsockopt(sock,0xFFFF,0x0020,&yes,sizeof(yes))>=0;
      if(!broadcast_enabled && !has_unicast){outbound_stage.store(-5);break;}
      connected=false;audio_peer.store(0);audio_stage.store(1);
      receive_sequence.reset();
      outbound_stage.store(1);
      // Discard audio from a dead session, not carry it into a new one.
      audio_queue.flush();
      // Force a new discovery beacon on the next frame.
      frames=(frames/62U+1U)*62U;
    }
    if(!connected && auth_ready.load(std::memory_order_acquire) && frames%62==0){
      char beacon[12]{};
      std::memcpy(beacon,"PV14",4);
      std::memcpy(beacon+4,pair_code,6);
      beacon[10]='\r';beacon[11]='\n';
      // Prefer a configured PC, but use broadcast too for recovery after DHCP changes.
      if(has_unicast){
        const int n=sceNetSendto(sock,beacon,sizeof(beacon),0,&pc,sizeof(pc));
        if(n==static_cast<int>(sizeof(beacon)))outbound_beacons.fetch_add(1);
        else outbound_error.store(n);
      }
      if(broadcast_enabled){
        const int n=sceNetSendto(sock,beacon,sizeof(beacon),0,&broadcast,sizeof(broadcast));
        if(n==static_cast<int>(sizeof(beacon)))outbound_beacons.fetch_add(1);
        else outbound_error.store(n);
      }
    }
    if(!connected){
      Sock4 peer{};unsigned peer_len=sizeof(peer);
      const int n=sceNetRecvfrom(sock,rx.data(),rx.size(),kNonBlock,&peer,&peer_len);
      if(n==12 && std::memcmp(rx.data(),"PA14",4)==0 &&
          std::memcmp(rx.data()+4,pair_code,6)==0 && rx[10]=='\r' && rx[11]=='\n' &&
          peer_len==sizeof(Sock4) && peer.family==kInet){
        const int rc=sceNetConnect(sock,&peer,peer_len);
        if(rc>=0){connected=true;last_rx_frame=frames;audio_peer.store(2);audio_stage.store(3);outbound_stage.store(2);outbound_error.store(0);}
        else outbound_error.store(rc);
      }
    }
    const int r=sceAudioInInput(mic,pcm.data());
    if(r<0){audio_mic_err.store(r);audio_stage.store(-6);break;}
    int peak=0;for(auto v:pcm){int a=v<0?-int(v):int(v);if(a>peak)peak=a;}
    audio_peak.store(peak);
    ++frames;
    if(!connected)continue;
    if(mic_muted.load())pcm.fill(0);
    lanvoice::write_packet(tx.data(),seq++,pcm.data());
    const int sent=sceNetSend(sock,tx.data(),tx.size(),0);
    if(sent==static_cast<int>(tx.size()))audio_sent.fetch_add(1);
    else outbound_error.store(sent);
    for(int k=0;k<2;++k){
      const int n=sceNetRecv(sock,rx.data(),rx.size(),kNonBlock);
      if(n<=0)break;
      std::uint32_t rseq=0;
      if(lanvoice::read_packet(rx.data(),n,rseq,received.data())){
        const bool accept=receive_sequence.accept(rseq);
        audio_seq_gaps.store(static_cast<int>(receive_sequence.gaps));
        audio_seq_rejected.store(static_cast<int>(receive_sequence.rejected));
        if(accept){audio_queue.push(received.data());audio_recv.fetch_add(1);}
        last_rx_frame=frames;
      }
    }
  }
  sceNetSocketClose(sock);
}

void* audio_worker(void*){
 sceUserServiceInitialize(nullptr);
 int user=-1;const int ur=sceUserServiceGetInitialUser(&user);
 if(ur<0){audio_mic_err.store(ur);audio_stage.store(-1);return nullptr;}
 audio_user.store(user);
 int mic=sceAudioInOpen(user,0,0,lanvoice::kFrames,lanvoice::kRate,0);
 if(mic<0)mic=sceAudioInOpen(user,1,0,lanvoice::kFrames,lanvoice::kRate,0);
 if(mic<0){audio_mic_err.store(mic);audio_stage.store(-2);return nullptr;}
 pthread_t playback{};
 if(pthread_create(&playback,nullptr,audio_playback,nullptr)==0)pthread_detach(playback);
 // Wait until one shared network initialization and pool exist.
 while(!net_started.load(std::memory_order_acquire)){
    if(stage.load()==-1 || stage.load()==-7 || stage.load()==-10){
       audio_stage.store(-7);sceAudioInClose(mic);return nullptr;
    }
    usleep(100000);
 }
 // V10 allocated a second pool unnecessarily, causing init races.
 // A single shared pool serves both TCP and UDP sockets.
 BindResult br{};
 std::array<std::int16_t,lanvoice::kFrames> probe_pcm{};
 for(int attempt=0;;++attempt){
   br=bind_listener("discord_v13_udp",kUdp,kAudioPort);
   udp_bind_err.store(br.result);
   udp_bind_mode.store(br.mode);
   udp_bind_attempts.fetch_add(br.tried);
   if(attempt==0 && br.fd<0)bind_probe_udp.store(ephemeral_bind_probe("discord_udp_probe",kUdp));
   if(br.fd>=0)break;
   audio_net_err.store(br.result);
   // On the first blocked listener, try outbound UDP rather than infinite bind retries.
   if(attempt==0){outbound_audio_fallback(mic);sceAudioInClose(mic);return nullptr;}
   audio_stage.store(-5);
   // Do not hide a working headset microphone behind a failed UDP bind.
   // Capture 16ms frames during backoff and preserve peak diagnostics.
   const int rounds=attempt<2?125:1875;
   for(int i=0;i<rounds;++i){
      const int rc=sceAudioInInput(mic,probe_pcm.data());
      if(rc<0){audio_mic_err.store(rc);audio_stage.store(-6);sceAudioInClose(mic);return nullptr;}
      int peak=0;
      for(auto v:probe_pcm){const int a=v<0?-int(v):int(v);if(a>peak)peak=a;}
      audio_peak.store(peak);
   }
 }
 int sock=br.fd;
 audio_net_err.store(0);
 bool connected=false;
 unsigned frames_since_rx=0;
 std::array<unsigned char,lanvoice::kPacketSize> rx{},tx{};
 std::array<std::int16_t,lanvoice::kFrames> pcm{},received{};
 std::uint32_t seq=0;
 lanvoice::RxSequence receive_sequence{};
 audio_stage.store(1);
 while(true){
   if(!connected && auth_ready.load(std::memory_order_acquire)){
     Sock4 candidate{};unsigned peer_size=sizeof(candidate);
     const int n=sceNetRecvfrom(sock,rx.data(),rx.size(),kNonBlock,&candidate,&peer_size);
     // Peer authentication uses the current on-screen local pairing code.
     if(n==12 && std::memcmp(rx.data(),"PV10",4)==0 && std::memcmp(rx.data()+4,pair_code,6)==0 && rx[10]=='\r' && rx[11]=='\n'){
       const int con=sceNetConnect(sock,&candidate,peer_size);
       if(con>=0){connected=true;frames_since_rx=0;audio_peer.store(1);audio_stage.store(2);audio_net_err.store(0);}
       else audio_net_err.store(con);
     }
   }
   // AudioInInput provides the 16ms pacing; no busy polling.
   const int r=sceAudioInInput(mic,pcm.data());
   if(r<0){audio_mic_err.store(r);audio_stage.store(-6);break;}
   int peak=0;for(auto v:pcm){int a=v<0?-int(v):int(v);if(a>peak)peak=a;}
   audio_peak.store(peak);
   if(!connected)continue;
   // A PS5 UDP socket connected to a stale Windows source port will not see
   // the new hello packets after a Windows restart. If no valid return audio
   // arrives for six seconds, recreate our listener at the same PS5 port.
   // Audio capture and headset playback remain untouched.
   if(++frames_since_rx > 375U){
     sceNetSocketClose(sock);
     sock=-1;
     audio_peer.store(0);audio_stage.store(1);
     audio_queue.flush();receive_sequence.reset();
     audio_reconnects.fetch_add(1);
     // Only a brief retry here; always keep capturing the microphone.
     BindResult renewed=bind_listener("discord_v16_rebind_udp",kUdp,kAudioPort);
     udp_bind_err.store(renewed.result);
     udp_bind_mode.store(renewed.mode);
     udp_bind_attempts.fetch_add(renewed.tried);
     if(renewed.fd<0){
       audio_net_err.store(renewed.result);
       // A failed rebind can be a transient sandbox/network transition.
       // Switch to the existing outbound fallback rather than terminating audio.
       outbound_audio_fallback(mic);
       sceAudioInClose(mic);return nullptr;
     }
     sock=renewed.fd;
     connected=false;frames_since_rx=0;
     continue;
   }
   if(mic_muted.load())pcm.fill(0);
    lanvoice::write_packet(tx.data(),seq++,pcm.data());
   const int sent=sceNetSend(sock,tx.data(),tx.size(),0);
   if(sent==int(tx.size()))audio_sent.fetch_add(1);else audio_net_err.store(sent);
   for(int k=0;k<3;++k){
     const int n=sceNetRecv(sock,rx.data(),rx.size(),kNonBlock);
     if(n<=0)break;
     std::uint32_t rseq=0;
     if(lanvoice::read_packet(rx.data(),n,rseq,received.data())){
       const bool accept=receive_sequence.accept(rseq);
       audio_seq_gaps.store(static_cast<int>(receive_sequence.gaps));
       audio_seq_rejected.store(static_cast<int>(receive_sequence.rejected));
       if(accept){audio_queue.push(received.data());audio_recv.fetch_add(1);frames_since_rx=0;}
     }
   }
 }
 sceAudioInClose(mic);sceNetSocketClose(sock);return nullptr;
}

// Dashboard composition inspired by the Pulse Dashboard / ten-foot UI principles
// documented in blackbearreloaded/ps5-homebrew-ui (no upstream code copied).
// All geometry uses the existing native Canvas; no new GL dependencies.
// Native Discord-theme surface using the real PS5 demo Canvas.
// No HTML mockup in the console binary. No third-party font files.
discord_ui::Navigation controller_navigation;
std::atomic<int> controller_status{0};
void poll_controller() noexcept {
 static int handle=-1,retry_frames=0;
 static bool initialized=false;
 if(handle<0){
  if(retry_frames>0){--retry_frames;return;}
  retry_frames=120;
  int user=-1;
  // Audio owns the user-service lifecycle; do not terminate it from the UI.
  if(sceUserServiceGetInitialUser(&user)<0 || user<0){controller_status.store(-1);return;}
  if(!initialized){
   const int rc=scePadInit();
   if(rc<0){controller_status.store(rc);return;}
   initialized=true;
  }
  handle=scePadOpen(user,ps5::pad::kPortStandard,0,nullptr);
  if(handle<0){controller_status.store(handle);return;}
 }
 std::array<ps5::pad::Data,ps5::pad::kBatchSamples> samples{};
 const int count=scePadRead(handle,samples.data(),static_cast<int>(samples.size()));
 if(count<0 || count>static_cast<int>(samples.size())){
  controller_status.store(count<0?count:-2);
  scePadClose(handle);handle=-1;controller_navigation.reset();return;
 }
 for(int i=0;i<count;++i){
  const auto& sample=samples[static_cast<std::size_t>(i)];
  controller_status.store(ps5::pad::is_usable(sample)?1:0);
  const auto action=controller_navigation.consume(sample);
  if(action.microphone)mic_muted.store(1-mic_muted.load());
  if(action.headphones)headset_muted.store(1-headset_muted.load());
  if(action.volume){
   int current=headset_volume.load();
   for(;;){const int value=current+action.volume;const int next=value<0?0:value>100?100:value;
    if(headset_volume.compare_exchange_weak(current,next))break;
   }
  }
 }
}
void draw(ps5::demo::Canvas& c) noexcept {
 poll_controller();
 using ps5::demo::Color;
 constexpr Color bg=Color::discordRaised,nav=Color::discordSidebar,panel=Color::discordSurface;
 constexpr Color white=Color::discordWhite,muted=Color::discordMuted,purple=Color::blurple;
 constexpr Color green=Color::discordGreen,red=Color::discordRed,stroke=Color::discordStroke;
 const bool online=stage.load(std::memory_order_acquire)==1;
 const bool lan=audio_peer.load()>0 && audio_sent.load()>0;
 char buf[180]{},name[40]{};
 pthread_mutex_lock(&name_lock);std::memcpy(name,discord_name,sizeof(name));pthread_mutex_unlock(&name_lock);
 if(std::strlen(name)>19){name[16]=name[17]=name[18]='.';name[19]=0;}
 auto text=[&](int x,int y,const char*t,int sz=2,Color color=Color::discordWhite){c.text(x,y,t,sz,color);};
 auto tile=[&](int x,int y,int w,int h,Color color){c.rectangle(x,y,w,h,color);};
 auto round=[&](int x,int y,int w,int h,int radius,Color color){
  tile(x+radius,y,w-2*radius,h,color);tile(x,y+radius,w,h-2*radius,color);
  c.circle(x+radius,y+radius,radius,color);c.circle(x+w-radius-1,y+radius,radius,color);
  c.circle(x+radius,y+h-radius-1,radius,color);c.circle(x+w-radius-1,y+h-radius-1,radius,color);
 };
 auto mic=[&](int x,int y,Color color){
  round(x+10,y,16,30,7,color);tile(x+3,y+22,4,16,color);tile(x+29,y+22,4,16,color);
  tile(x+7,y+36,22,4,color);tile(x+16,y+40,4,10,color);tile(x+9,y+49,18,4,color);
 };
 auto phones=[&](int x,int y,Color color){
  c.circle(x+22,y+22,22,color);c.circle(x+22,y+22,17,panel);tile(x,y+22,44,24,panel);
  round(x,y+22,10,23,4,color);round(x+34,y+22,10,23,4,color);
 };
 c.clear(bg);
 tile(0,0,96,1080,nav);tile(96,0,364,1080,panel);
 tile(460,0,1460,88,panel);tile(1510,88,410,992,panel);
 tile(0,29,5,46,white);round(19,20,58,60,18,purple);text(35,33,"D",4);
 tile(26,104,44,2,stroke);round(19,126,58,60,20,Color::discordBubble);text(31,147,"PS",2);
 c.circle(48,224,27,panel);text(34,213,"+",3,green);
 text(122,29,"Discord",3);text(405,31,"v",2,muted);tile(96,87,1414,2,nav);
 text(122,125,"DEINE KONSOLE",2,muted);
 round(110,166,335,54,7,stroke);text(130,182,"#  verbindung",2);
 text(123,262,"v  SPRACHBEREICH",2,muted);
 text(134,311,">  PS5 Headset",2);
 c.circle(161,380,17,purple);text(156,370,"D",2);text(190,370,name[0]?name:"Du",2);
 c.circle(170,393,6,lan?green:muted);
 text(134,443,">  Windows Bridge",2,muted);
 text(123,548,"DISCORD SERVER",2,muted);
 text(133,595,"Auswahl am PC",2);
 text(123,639,"Dein Sprachkanal wird",2,muted);text(123,671,"im PC-Client gewaehlt.",2,muted);
 tile(96,882,364,100,Color::discordBg);c.circle(125,910,6,lan?green:muted);
 text(143,900,lan?"Audiobruecke aktiv":"Warte auf PC",2,lan?green:muted);
 text(122,944,"PS5 Headset / Windows",2,muted);
 tile(96,984,364,96,nav);c.circle(135,1029,24,purple);text(128,1016,"D",2);
 text(176,1006,name[0]?name:"Dein Headset",2);text(176,1040,mic_muted.load()?"Mikrofon stumm":"Bereit",2,mic_muted.load()?red:muted);
 text(494,29,"#  verbindung",3);text(1160,36,"V21 / VOICE BETA",2,muted);
 text(506,125,"SPRACHBEREICH",2,muted);
 text(506,166,"Dein Platz im Voice.",4);
 c.circle(519,238,6,lan?green:muted);text(538,228,lan?"Audiobruecke verbunden":"Windows-Bruecke verbinden",2,lan?green:muted);
 // Voice tiles represent real devices, not invented Discord participants.
 round(506,289,466,316,16,controller_navigation.focus==0?purple:panel);
 round(510,293,458,308,13,panel);
 if(!mic_muted.load() && audio_peak.load()>700)c.circle(739,411,64,green);
 c.circle(739,411,58,Color::discordBubble);mic(721,382,mic_muted.load()?red:white);
 text(531,315,"DEIN MIKROFON",2,muted);
 text(532,531,mic_muted.load()?"Stummgeschaltet":audio_mic_err.load()<0?"Mikrofonfehler":audio_stage.load()>0?"PS5 Headset":"Warte auf Headset",3,mic_muted.load()?red:white);
 text(532,575,"QUADRAT  /  X",2,muted);
 round(994,289,466,316,16,controller_navigation.focus==1?purple:panel);
 round(998,293,458,308,13,panel);text(1019,315,"DEINE AUSGABE",2,muted);
 c.circle(1227,411,58,Color::discordBubble);phones(1205,388,headset_muted.load()?red:white);
 text(1020,531,headset_muted.load()?"Stummgeschaltet":audio_out_err.load()<0?"Ausgabefehler":"Kopfhoerer",3,headset_muted.load()?red:white);
 text(1020,575,"DREIECK  /  X",2,muted);
 text(506,651,"MIKROFONPEGEL",2,muted);
 const int peak=audio_peak.load();
 for(int i=0;i<48;++i)round(506+i*20,687,13,10,3,!mic_muted.load() && peak>i*32768/48?green:stroke);
 round(506,743,954,118,12,controller_navigation.focus==2?purple:panel);
 round(510,747,946,110,9,panel);
 text(533,764,"LAUTSTAERKE",2,muted);std::snprintf(buf,sizeof(buf),"%d%%",headset_volume.load());text(1340,764,buf,2);
 tile(534,819,822,7,stroke);tile(534,819,headset_volume.load()*822/100,7,purple);
 c.circle(534+headset_volume.load()*822/100,822,9,white);
 text(1377,814,"L1/R1",1,muted);
 text(506,897,"Server und Sprachkanal im Windows-Discord waehlen.",2,muted);
 tile(460,982,1050,98,Color::discordBg);
 text(506,1006,"D-Pad Auswahl    X Umschalten    L1/R1 Lautstaerke",2);
 text(506,1043,"OPTIONS Verbindungsdetails",2,muted);
 text(1540,130,"VERBINDUNG",2,muted);
 text(1540,185,online?"Webserver online":"Webserver offline",2,online?green:red);
 if(ip_ready.load()){std::snprintf(buf,sizeof(buf),"%s:4747",ip);text(1540,237,buf,2);}
 else text(1540,237,"IP wird gesucht",2,muted);
 text(1540,299,"KOPPLUNGSCODE",2,muted);
 std::snprintf(buf,sizeof(buf),"PAIRING CODE   %s",auth_ready.load()?pair_code:"WAITING");
 // Keep this marker available to the simulator without enlarging the visible code.
 text(1540,350,auth_ready.load()?pair_code:"WAITING",4);
 static bool pair_printed=false;
 if(auth_ready.load() && !pair_printed){std::fprintf(stderr,"SCREEN: %s\n",buf);pair_printed=true;}
 char active_code[33]{};discord_v9::LocalQR active_qr;
 pthread_mutex_lock(&device_lock);
 const bool activating=device_code[0] && std::time(nullptr)<device_expires;
 if(activating){std::memcpy(active_code,device_code,sizeof(active_code));active_qr=device_qr;}
 pthread_mutex_unlock(&device_lock);
 if(activating || (online && qr_ready.load())){
   constexpr int unit=8,left=1584,top=429;
   tile(left-24,top-24,280,280,white);
   for(int y=0;y<29;++y)for(int x=0;x<29;++x)if(activating?active_qr.dark[y][x]:local_qr.dark[y][x])tile(left+x*unit,top+y*unit,unit,unit,nav);
   text(1540,710,activating?"Discord: Code eingeben":"QR: lokale PS5-Seite",2,muted);
   if(activating)text(1540,746,active_code,std::strlen(active_code)>19?1:2);
 }else{text(1540,447,"QR nicht verfuegbar",2,muted);}
 text(1540,782,"DISCORD KONTO",2,muted);text(1540,827,name[0]?name:"Nicht angemeldet",2);
 text(1540,884,"CONTROLLER",2,muted);text(1540,923,controller_status.load()==1?"Verbunden":"Nicht verfuegbar",2,controller_status.load()==1?green:muted);
 // Direct Discord voice join: NOT IMPLEMENTED.
 if(controller_navigation.diagnostics){
  round(506,289,954,572,16,nav);text(544,328,"Verbindungsdetails",3);
  text(544,394,"Nur lokaler Audiotransport, kein Kanalstatus.",2,muted);
  std::snprintf(buf,sizeof(buf),"TCP %08X  UDP %08X",static_cast<unsigned>(bind_result.load()),static_cast<unsigned>(udp_bind_err.load()));text(544,469,buf,2);
  std::snprintf(buf,sizeof(buf),"PROBE %08X/%08X",static_cast<unsigned>(bind_probe_http.load()),static_cast<unsigned>(bind_probe_udp.load()));text(544,522,buf,2,muted);
  std::snprintf(buf,sizeof(buf),"Pakete gesendet %d / empfangen %d",audio_sent.load(),audio_recv.load());text(544,584,buf,2);
  text(544,656,online?"PS5-Webserver erreichbar":"PS5-Webserver nicht verfuegbar",2,online?green:red);
  text(544,780,"OPTIONS oder KREIS zum Schliessen",2,muted);
 }

}

}
int main(){pthread_t t{};
 if(pthread_create(&t,nullptr,server_worker,nullptr)==0)pthread_detach(t);
 pthread_t a{};
 if(pthread_create(&a,nullptr,audio_worker,nullptr)==0)pthread_detach(a);
 else stage.store(-6);
 ps5::demo::run_frames(draw,"Discord");
}
