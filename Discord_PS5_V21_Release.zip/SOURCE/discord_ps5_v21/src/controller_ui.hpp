// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "ps5_pad.hpp"
namespace discord_ui {
struct Action { bool microphone=false; bool headphones=false; int volume=0; };
class Navigation {
 std::uint32_t previous_=0;
 std::uint8_t generation_=0;
 bool tracking_=false;
public:
 int focus=0;
 bool diagnostics=false;
 void reset() noexcept {tracking_=false;previous_=0;}
 Action consume(const ps5::pad::Data& sample) noexcept {
  Action action{};
  if(!ps5::pad::is_usable(sample)){reset();return action;}
  // Reconnect and system-menu return must not activate an already held button.
  if(!tracking_ || generation_!=sample.connection_generation){
   tracking_=true;generation_=sample.connection_generation;previous_=sample.buttons;return action;
  }
  const auto pressed=sample.buttons & ~previous_;previous_=sample.buttons;
  using namespace ps5::pad;
  if(pressed & kButtonOptions)diagnostics=!diagnostics;
  if(pressed & kButtonCircle)diagnostics=false;
  if(pressed & kButtonUp)focus=(focus+2)%3;
  if(pressed & kButtonDown)focus=(focus+1)%3;
  action.microphone=(pressed & kButtonSquare)!=0 || ((pressed & kButtonCross)!=0 && focus==0);
  action.headphones=(pressed & kButtonTriangle)!=0 || ((pressed & kButtonCross)!=0 && focus==1);
  if(pressed & kButtonL1)action.volume-=5;
  if(pressed & kButtonR1)action.volume+=5;
  if(focus==2){
   if(pressed & kButtonLeft)action.volume-=5;
   if(pressed & kButtonRight)action.volume+=5;
  }
  return action;
 }
};
}
