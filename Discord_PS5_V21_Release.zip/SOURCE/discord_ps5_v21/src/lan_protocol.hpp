#pragma once
#include <cstdint>
#include <cstring>

namespace lanvoice {
constexpr unsigned kFrames=256;
constexpr unsigned kRate=16000;
constexpr unsigned kPacketSize=8 + 2*kFrames;
constexpr unsigned kPort=43670;
constexpr unsigned kRunBlocks=1250; // 20 seconds of microphone frames.

inline void write_packet(unsigned char *out, std::uint32_t seq, const std::int16_t* audio) noexcept {
    out[0]='P';out[1]='V';out[2]='7';out[3]='A';
    out[4]=static_cast<unsigned char>(seq);
    out[5]=static_cast<unsigned char>(seq>>8);
    out[6]=static_cast<unsigned char>(seq>>16);
    out[7]=static_cast<unsigned char>(seq>>24);
    for(unsigned i=0;i<kFrames;++i){
        const auto v=static_cast<std::uint16_t>(audio[i]);
        out[8+2*i]=static_cast<unsigned char>(v);
        out[9+2*i]=static_cast<unsigned char>(v>>8);
    }
}
inline bool read_packet(const unsigned char* in, int n, std::uint32_t& seq, std::int16_t* audio) noexcept {
    if(n!=static_cast<int>(kPacketSize) || in[0]!='P'||in[1]!='V'||in[2]!='7'||in[3]!='A') return false;
    seq=static_cast<std::uint32_t>(in[4]) | (static_cast<std::uint32_t>(in[5])<<8) |
        (static_cast<std::uint32_t>(in[6])<<16) | (static_cast<std::uint32_t>(in[7])<<24);
    for(unsigned i=0;i<kFrames;++i){
        const auto v=static_cast<std::uint16_t>(in[8+2*i]) | static_cast<std::uint16_t>(in[9+2*i])<<8;
        audio[i]=static_cast<std::int16_t>(v);
    }
    return true;
}
}
