#pragma once
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
namespace discord_v9 {
inline bool same(const char *a, const char *b) noexcept {return a && b && std::strcmp(a,b)==0;}
// Only GET and POST, HTTP/1.x, no pipelining, no chunked bodies.
struct Request {char method[8]{};char path[96]{};bool valid=false;bool overflow=false;};
inline Request parse_request(const char* buf, std::size_t n) noexcept {
 Request r{};
 if(!buf || n<12 || n>2048) return r;
 const char *end=static_cast<const char*>(std::memchr(buf,'\n',n));
 if(!end || static_cast<std::size_t>(end-buf)>180)return r;
 char ver[16]{};
 int consumed=0;
 if(std::sscanf(buf,"%7s %95s %15s%n",r.method,r.path,ver,&consumed)!=3)return r;
 if(!(same(r.method,"GET")||same(r.method,"POST")))return r;
 if(std::strncmp(ver,"HTTP/1.",7)!=0)return r;
 if(r.path[0]!='/' || std::strstr(r.path,"..") || std::strchr(r.path,'\\'))return r;
 r.valid=true;return r;
}
inline bool token_from_cookie(const char *headers,std::size_t n,const char *wanted)noexcept {
 if(!headers || !wanted || std::strlen(wanted)!=32)return false;
 const char* cur=headers;const char* end=headers+n;
 while(cur<end){const char* p=std::strstr(cur,"Cookie:");if(!p || p>=end)break;
   const char* linend=std::strstr(p,"\r\n");if(!linend||linend>end)break;
   const char* k=std::strstr(p,"ps5_session=");
   if(k && k<linend && static_cast<std::size_t>(linend-(k+12))>=32 &&
     std::memcmp(k+12,wanted,32)==0 && (k[44]==';'||k[44]=='\r'||k[44]==' ')) return true;
   cur=linend+2;
 }
 return false;
}
}
