# V21 Voice UI Beta

- PS5-Sprachbereich im Discord-Stil mit Gerätekacheln und Audio-Symbolen.
- Sprechindikator und segmentierte Pegelanzeige.
- Lautstärkebalken und sichtbare Controller-Auswahl.
- OPTIONS öffnet Diagnose, Kreis schließt sie.
- Passende Browseroberfläche mit Bereichsnavigation und korrekter Offline-Anzeige.
- Audiobrücke und optionaler Gerätecode-Login aus V20 übernommen.

Kein direkter Discord-Kanalbeitritt auf der PS5. Hardwaretest steht aus.
