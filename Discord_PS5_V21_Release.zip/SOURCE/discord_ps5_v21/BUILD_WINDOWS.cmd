@echo off
setlocal EnableExtensions
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1"
if errorlevel 1 echo BUILD FEHLGESCHLAGEN. Bitte die Fehlermeldung oben beachten.
pause
