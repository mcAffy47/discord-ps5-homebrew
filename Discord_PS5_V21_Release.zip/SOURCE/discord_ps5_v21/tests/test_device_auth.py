from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pc'))
from device_auth import DeviceAuthorization
class Timer:
    def __init__(self):self.now=0;self.waits=[]
    def wait(self,value):self.waits.append(value);self.now+=value;return False
    def clear(self):pass

def fixture(replies,expiry=40):
    clock=Timer();codes=[]
    flow=DeviceAuthorization('123','secret',lambda c,t:codes.append((c,t)),clock=lambda:clock.now)
    flow._stop=clock
    calls=[]
    def post(path,data):
        calls.append((path,data))
        if path.endswith('/authorize'):
            return {'user_code':'ABCD-EFGH','device_code':'private-device-code','expires_in':expiry,'interval':5}
        return replies.pop(0)
    flow._post=post
    return flow,clock,codes,calls
flow,clock,codes,calls=fixture([{'error':'authorization_pending'},{'error':'slow_down'},{'access_token':'never-expose-this'}])
flow._run();assert flow.snapshot()['state']=='authorized'
assert clock.waits==[5,5,10],clock.waits
assert codes==[('ABCD-EFGH',40),('',0)]
assert 'never-expose' not in str(flow.snapshot())
assert calls[1][1]['grant_type']=='urn:ietf:params:oauth:grant-type:device_code'
flow,clock,codes,calls=fixture([{'error':'access_denied'}]);flow._run();assert flow.snapshot()['state']=='denied'
flow,clock,codes,calls=fixture([],expiry=2);flow._run();assert flow.snapshot()['state']=='expired';assert len(calls)==1
flow=DeviceAuthorization('123','secret');flow._post=lambda *args:{'user_code':'<script>','device_code':'s','interval':5,'expires_in':300}
flow._run();assert flow.snapshot()['state']=='error'
try:DeviceAuthorization('123','').start()
except ValueError:pass
else:raise AssertionError('Missing configuration accepted')
print('PASS: official grant format, pending/slow_down timing, expiry, denial, malformed code, no token disclosure')
