#include "../src/ps5_pad.hpp"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <chrono>
#include <thread>
#include <atomic>
#include <cstdlib>
struct PS5Addr {std::uint8_t len,family;std::uint16_t port;std::uint8_t ip[4],pad[8];};
static_assert(sizeof(PS5Addr)==16);
static sockaddr_in to_native(const void *ptr){PS5Addr a{};std::memcpy(&a,ptr,16);sockaddr_in b{};b.sin_family=AF_INET;b.sin_port=a.port;std::memcpy(&b.sin_addr,a.ip,4);return b;}
static void to_ps5(void*ptr,const sockaddr_in&b){PS5Addr a{};a.len=16;a.family=2;a.port=b.sin_port;std::memcpy(a.ip,&b.sin_addr,4);std::memcpy(ptr,&a,16);}
extern "C"{
int scePadInit(){return 0;}
int scePadOpen(int,int,int,const void*){return 1;}
int scePadClose(int){return 0;}
int scePadRead(int,ps5::pad::Data*data,int capacity){
 if(capacity<1)return -1;
 *data=ps5::pad::neutral_data();data->connected=1;
 if(std::getenv("DISCORD_TEST_OPTIONS") && capacity>=2){data[1]=data[0];data[1].buttons=ps5::pad::kButtonOptions;return 2;}
 return 1;
}

int sceNetCtlInit(){return 0;}
int sceNetInit(){return 0;}
int sceNetPoolCreate(const char*,int,int){return 2101;}
int sceNetSocket(const char*,int,int t,int){return socket(AF_INET,t==1?SOCK_STREAM:SOCK_DGRAM,0);}
int sceNetBind(int s,const void*p,unsigned){
 static std::atomic<bool> failed_http{false},failed_udp{false};
 auto a=to_native(p);
 if(std::getenv("V14_FORCE_BIND_FAILURE"))return static_cast<int>(0x80410100U);
 if(std::getenv("V14_SIMULATE_BIND_FAILURE")){
    std::atomic<bool>& flag=(ntohs(a.sin_port)==4747)?failed_http:failed_udp;
    if(!flag.exchange(true))return static_cast<int>(0x804101A0U);
 }a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);if(ntohs(a.sin_port)==4747)a.sin_port=htons(14747);int v=1;setsockopt(s,SOL_SOCKET,SO_REUSEADDR,&v,sizeof(v));return bind(s,(sockaddr*)&a,sizeof(a));}
int sceNetListen(int s,int q){return listen(s,q);}
int sceNetAccept(int s,void*p,unsigned*n){sockaddr_in a{};socklen_t sz=sizeof(a);int fd=accept(s,(sockaddr*)&a,&sz);if(fd>=0&&p){to_ps5(p,a);*n=16;}return fd;}
int sceNetConnect(int s,const void*p,unsigned){auto a=to_native(p);if(ntohs(a.sin_port)==53)a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);return connect(s,(sockaddr*)&a,sizeof(a));}
int sceNetGetsockname(int s,void*p,unsigned*n){sockaddr_in a{};socklen_t z=sizeof(a);int r=getsockname(s,(sockaddr*)&a,&z);if(r>=0){to_ps5(p,a);*n=16;}return r;}
int sceNetSend(int s,const void*p,unsigned n,int f){return static_cast<int>(send(s,p,n,f));}
int sceNetRecv(int s,void*p,unsigned n,int f){return static_cast<int>(recv(s,p,n,f==0x80?MSG_DONTWAIT:f));}
int sceNetRecvfrom(int s,void*p,unsigned n,int f,void*a,unsigned*len){sockaddr_in addr{};socklen_t size=sizeof(addr);int r=recvfrom(s,p,n,f==0x80?MSG_DONTWAIT:f,(sockaddr*)&addr,&size);if(r>=0&&a){to_ps5(a,addr);*len=16;}return r;}
int sceNetSendto(int s,const void*p,unsigned n,int f,const void*a,unsigned){auto addr=to_native(a);if(std::getenv("DISCORD_HOST_BROADCAST_LOOPBACK") && (ntohl(addr.sin_addr.s_addr)&255U)==255U)addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);return sendto(s,p,n,f,(sockaddr*)&addr,sizeof(addr));}
int sceUserServiceInitialize(void*){return 0;}
int sceUserServiceGetInitialUser(int*user){*user=100;return 0;}
int sceAudioInOpen(int,int,int,unsigned,unsigned,unsigned){return 801;}
int sceAudioInInput(int,void*p){std::memset(p,0,512);if(std::getenv("V19_TEST_MIC_NONZERO")){auto* samples=static_cast<std::int16_t*>(p);for(int i=0;i<256;++i)samples[i]=1200;}std::this_thread::sleep_for(std::chrono::milliseconds(16));return 0;}
int sceAudioInClose(int){return 0;}
int sceAudioOutInit(){return 0;}
int sceAudioOutOpen(int,int,int,unsigned,unsigned,unsigned){return 802;}
int sceAudioOutOutput(int,const void*pcm){
 if(const char*path=std::getenv("V19_TEST_OUTPUT_LOG")){
  const auto* samples=static_cast<const std::int16_t*>(pcm);int peak=0;
  for(int i=0;i<512;++i){const int v=samples[i]<0?-int(samples[i]):int(samples[i]);if(v>peak)peak=v;}
  if(FILE*f=std::fopen(path,"a")){std::fprintf(f,"%d\n",peak);std::fclose(f);}
 }
 std::this_thread::sleep_for(std::chrono::milliseconds(5));return 0;
}
int sceAudioOutClose(int){return 0;}
int sceNetSocketClose(int s){return close(s);}
int sceNetSetsockopt(int s,int,int opt,const void*val,unsigned n){if(opt==4)return setsockopt(s,SOL_SOCKET,SO_REUSEADDR,val,n);if(opt==0x20){if(std::getenv("V14_DISABLE_BROADCAST"))return -1;return setsockopt(s,SOL_SOCKET,SO_BROADCAST,val,n);}if(opt==0x1006){const int *p=(const int*)val;timeval tv{p[0],p[1]};return setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));}return -1;}
int sceNetInetPton(int af,const char*p,void*d){return inet_pton(af,p,d);}
unsigned short sceNetHtons(unsigned short x){return htons(x);}
}
