import http.client, subprocess, time, re, pathlib, signal, socket, struct
base=pathlib.Path(__file__).resolve().parents[1]
exe='/tmp/discord_v13_host_server'
cmd=['clang++','-std=c++20','-Wall','-Wextra','-Werror','-pthread','-I',str(base/'tests/host_include'),'-I',str(base/'src'),str(base/'src/main.cpp'),str(base/'tests/host_sce_shim.cpp'),'-o',exe]
subprocess.run(cmd,check=True)
p=subprocess.Popen([exe],stderr=subprocess.PIPE,text=True)
try:
    time.sleep(1.0)
    def req(method,path,body=None,headers=None):
        conn=http.client.HTTPConnection('127.0.0.1',14747,timeout=3)
        conn.request(method,path,body=body,headers=headers or {})
        res=conn.getresponse();out=(res.status,res.getheaders(),res.read());conn.close();return out
    status,headers,body=req('GET','/')
    assert status==200 and b'Discord' in body, (status,body[:100])
    status,_,_=req('GET','/api/status')
    assert status==401,status
    status,_,_=req('POST','/api/pair',b'000000',{'Content-Type':'text/plain'})
    assert status==403,status
    status,_,_=req('GET','/../')
    assert status==400,status
    # Read displayed pairing code from stub Canvas and make a real HTTP pairing call.
    # Buffered stderr is line-buffered by fprintf to unbuffered stderr.
    lines=[]
    end=time.time()+3
    while time.time()<end:
       line=p.stderr.readline()
       lines.append(line)
       m=re.search(r'PAIRING CODE   (\d{6})',line)
       if m:
          code=m.group(1).encode();break
    else:raise AssertionError('No pairing code on simulated display')
    status,headers,body=req('POST','/api/pair',code,{'Content-Type':'text/plain'})
    assert status==200,(status,body)
    cookie=next((v.split(';')[0] for k,v in headers if k.lower()=='set-cookie'),None)
    assert cookie and len(cookie)==44
    status,_,body=req('GET','/api/status',headers={'Cookie':cookie})
    assert status==200,(status,body)
    assert b'not_integrated' in body and b'V21 VOICE UI BETA' in body and b'"audio_reconnects":' in body
    # Companion OAuth result is accepted only for on-screen pairing code.
    status,_,_=req('POST','/api/discord/result',b'000000\nFake',{'Content-Type':'text/plain'})
    assert status==403,status
    status,_,body=req('POST','/api/discord/result',code+b'\nDiscordUser',{'Content-Type':'text/plain'})
    assert status==200,(status,body)
    status,_,body=req('GET','/api/status',headers={'Cookie':cookie})
    assert status==200 and b'DiscordUser' in body and b'"discord_linked":true' in body,(status,body)
    # Real UDP handshake with the mocked native PS5 socket and microphone samples.
    udp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    udp.bind(('127.0.0.1',0));udp.settimeout(2.5)
    packet=b'PV10'+code+b'\r\n'
    for _ in range(5):
        udp.sendto(packet,('127.0.0.1',43670))
        try: payload,peer=udp.recvfrom(2048);break
        except socket.timeout:continue
    else:raise AssertionError('No PCM from PS5 after pairing UDP handshake')
    assert len(payload)==520 and payload.startswith(b'PV7A'),(len(payload),payload[:8])
    udp.sendto(payload,('127.0.0.1',43670));udp.close()
    status,_,body=req('GET','/api/status',headers={'Cookie':cookie})
    assert status==200 and b'"audio_sent":' in body and b'"audio_peer":1' in body,(status,body)
    print('PASS: HTTP 200, unauthenticated 401, pairing 403/200, authenticated JSON 200, traversal 400')
finally:
    p.terminate()
    try:p.communicate(timeout=2)
    except subprocess.TimeoutExpired:p.kill()
