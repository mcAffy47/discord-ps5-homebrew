"""Native-host simulation: PS5 should reopen its direct voice UDP socket
when a Windows restart changes the source port. Keeps audio core unchanged.
"""
import os, socket, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v16_3_direct_restart'
subprocess.run(['clang++','-std=c++20','-Wall','-Wextra','-Werror','-pthread',
    '-I',str(root/'tests/host_include'),'-I',str(root/'src'),
    str(root/'src/main.cpp'),str(root/'tests/host_sce_shim.cpp'),'-o',exe],check=True)
p=subprocess.Popen([exe],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,bufsize=1)
a=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
b=None
try:
    import re,threading
    paired=threading.Event()
    code_box=[]
    # Drain the high-frequency simulator display without buffering megabytes.
    def capture():
        for line in p.stderr:
            if not paired.is_set():
                match=re.search(r'PAIRING CODE   (\d{6})',line)
                if match:code_box.append(match.group(1).encode());paired.set()
    threading.Thread(target=capture,daemon=True).start()
    assert paired.wait(5),'No simulated PS5 pairing code'
    code=code_box[0]
    a.bind(('127.0.0.1',0));a.settimeout(.6)
    hello=b'PV10'+code+b'\r\n'
    # V16.3 native listener direct mode
    first=None
    for attempt in range(8):
        a.sendto(hello,('127.0.0.1',43670))
        try:
            first,_=a.recvfrom(2048)
            if first.startswith(b'PV7A') and len(first)==520:break
        except socket.timeout:pass
    assert first is not None and len(first)==520,'PS5 direct audio never connected'
    a.sendto(first,('127.0.0.1',43670))
    # Simulate a Windows restart: new local source port, old socket stops replying.
    b=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    b.bind(('127.0.0.1',0));b.settimeout(.3)
    result=None;start=time.monotonic()
    while time.monotonic()-start<11:
        b.sendto(hello,('127.0.0.1',43670))
        try:
            pkt,_=b.recvfrom(2048)
            if len(pkt)==520 and pkt[:4]==b'PV7A':result=pkt;break
        except socket.timeout:pass
        time.sleep(.05)
    assert result is not None,'PS5 did not reconnect to the new PC UDP source port'
    b.sendto(result,('127.0.0.1',43670))
    print('PASS: direct PC source port changed, PS5 audio session recovered without restarting app; %.1fs' % (time.monotonic()-start))
finally:
    a.close()
    if b is not None:b.close()
    p.terminate()
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.kill()
