#include "controller_ui.hpp"
#include <cassert>
int main(){
 using namespace ps5::pad;discord_ui::Navigation n;
 auto s=neutral_data();s.connected=1;
 assert(!n.consume(s).microphone);
 s.buttons=kButtonCross;assert(n.consume(s).microphone);assert(!n.consume(s).microphone);
 s.buttons=0;n.consume(s);s.buttons=kButtonDown;n.consume(s);assert(n.focus==1);
 s.buttons=0;n.consume(s);s.buttons=kButtonCross;assert(n.consume(s).headphones);
 s.buttons=kButtonSystemOwned|kButtonSquare;assert(!n.consume(s).microphone);
 s.buttons=kButtonSquare;assert(!n.consume(s).microphone);
 s.buttons=0;n.consume(s);s.buttons=kButtonSquare;assert(n.consume(s).microphone);
 s.connected=0;assert(!n.consume(s).microphone);s.connected=1;assert(!n.consume(s).microphone);
 s.buttons=0;n.consume(s);++s.connection_generation;s.buttons=kButtonSquare;assert(!n.consume(s).microphone);
 s.buttons=0;n.consume(s);s.buttons=kButtonDown;n.consume(s);assert(n.focus==2);
 s.buttons=0;n.consume(s);s.buttons=kButtonLeft;assert(n.consume(s).volume==-5);
 s.buttons=kButtonRight;assert(n.consume(s).volume==5);
 s.buttons=kButtonOptions;n.consume(s);assert(n.diagnostics);n.consume(s);assert(n.diagnostics);
 s.buttons=kButtonCircle;n.consume(s);assert(!n.diagnostics);
 s.buttons=kButtonL1|kButtonR1;assert(n.consume(s).volume==0);
}
