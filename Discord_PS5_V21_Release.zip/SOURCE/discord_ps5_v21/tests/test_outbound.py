"""Host regression for the alternative outbound-first UDP path without explicit PS5 bind."""
from pathlib import Path
import os,socket,subprocess,threading,time
base=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v14_host_outbound'
subprocess.run(['clang++','-std=c++20','-Wall','-Wextra','-Werror','-pthread',
    '-I',str(base/'tests/host_include'),'-I',str(base/'src'),
    str(base/'src/main.cpp'),str(base/'tests/host_sce_shim.cpp'),'-o',exe],check=True)
server=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
server.bind(('0.0.0.0',43671));server.settimeout(.75)
received={'beacons':0,'pcm':0,'echoed':0}
finished=threading.Event()
def listener():
  while not finished.is_set():
    try:packet,addr=server.recvfrom(2048)
    except socket.timeout:continue
    if packet.startswith(b'PV14') and len(packet)==12:
      received['beacons']+=1
      server.sendto(b'PA14'+packet[4:10]+b'\r\n',addr)
    elif packet.startswith(b'PV7A') and len(packet)==520:
      received['pcm']+=1
      server.sendto(packet,addr)
      received['echoed']+=1
thread=threading.Thread(target=listener,daemon=True);thread.start()
p=subprocess.Popen([exe],env={**os.environ,'V14_FORCE_BIND_FAILURE':'1','DISCORD_HOST_BROADCAST_LOOPBACK':'1'},
                   stderr=subprocess.DEVNULL,stdout=subprocess.DEVNULL)
try:
  deadline=time.monotonic()+9
  while time.monotonic()<deadline and received['pcm']<4:
    time.sleep(.15)
  assert received['beacons']>0, 'PS5 outbound broadcast never reached PC listener'
  assert received['pcm']>=4, f'PS5 audio did not reach PC (observed {received})'
  print('PASS: PS5 bind forcibly denied; outbound discovery and UDP echo succeed:',received)
finally:
  finished.set();p.terminate()
  try:p.wait(timeout=2)
  except subprocess.TimeoutExpired:p.kill()
  server.close()
