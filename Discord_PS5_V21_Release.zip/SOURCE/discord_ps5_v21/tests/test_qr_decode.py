"""Optional genuine QR decode with OpenCV; QR generator basic C++ test runs unconditionally."""
from pathlib import Path
import subprocess
base=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v16_1_qr'
subprocess.run(['clang++','-std=c++20','-Wall','-Wextra','-Werror','-I',str(base/'src'),str(base/'tests/test_qr.cpp'),'-o',exe],check=True)
subprocess.run([exe],check=True)
try:
    import cv2
except ImportError:
    print('SKIP: OpenCV QR decoding unavailable in WSL; QR matrix generation passed')
else:
    image=cv2.imread('/tmp/discord_v9_qr.pbm',cv2.IMREAD_GRAYSCALE)
    assert image is not None
    scaled=cv2.resize(image,None,fx=12,fy=12,interpolation=cv2.INTER_NEAREST)
    decoded,points,_=cv2.QRCodeDetector().detectAndDecode(scaled)
    assert decoded=='http://192.168.178.36:4747',repr(decoded)
    print('PASS: generated QR is actually decodable and contains exact PS5 URL')
