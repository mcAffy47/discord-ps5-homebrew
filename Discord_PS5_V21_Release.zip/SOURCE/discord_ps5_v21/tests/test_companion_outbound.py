"""Exercise the actual Windows companion's outbound discovery/echo handler on localhost."""
from pathlib import Path
import importlib.util,threading,socket,time,struct,sys
p=Path(__file__).resolve().parents[1]/'pc'/'companion.py'
sys.path.insert(0,str(p.parent))
spec=importlib.util.spec_from_file_location('companion_v14_test',p)
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)
comp=c.Companion('192.168.178.36','123456','','echo')
comp.ps5_ip='127.0.0.1' # localhost fixture; user input still rejects loopback
thread=threading.Thread(target=comp.serve_audio,daemon=True)
thread.start();time.sleep(.2)
ps5=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
ps5.bind(('127.0.0.1',0));ps5.settimeout(2.0)
try:
    beacon=b'PV14'+b'123456'+b'\r\n'
    ps5.sendto(beacon,('127.0.0.1',43671))
    ack,peer=ps5.recvfrom(1024)
    assert ack==b'PA14123456\r\n',ack
    pkt=c.audio_packet(123,b'\x03\x07'*256)
    ps5.sendto(pkt,peer)
    reply,other=ps5.recvfrom(2048)
    assert reply==pkt,(reply[:20],other)
    assert comp.audio_rx>=1 and comp.audio_tx>=1
    print('PASS: actual Windows companion ACKs PS5 outbound discovery and echoes 520-byte PCM')
finally:
    comp.stop.set();ps5.close();thread.join(timeout=2.0)
