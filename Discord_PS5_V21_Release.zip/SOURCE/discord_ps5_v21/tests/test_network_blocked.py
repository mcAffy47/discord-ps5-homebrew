"""Verify the app does not advertise QR/Web success if TCP+UDP bind fail."""
from pathlib import Path
import subprocess,os,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v13_blocked'
cmd=['clang++','-std=c++20','-Wall','-Wextra','-Werror','-pthread','-I',str(p/'tests/host_snapshot'),'-I',str(p/'src'),str(p/'src/main.cpp'),str(p/'tests/host_sce_shim.cpp'),'-o',exe]
subprocess.run(cmd,check=True)
svg='/tmp/discord_v13_blocked.svg'
env={**os.environ,'V14_FORCE_BIND_FAILURE':'1','DISCORD_SNAPSHOT_SVG':svg}
subprocess.run([exe],env=env,check=True,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
s=Path(svg).read_text()
assert 'QR nicht verfuegbar' in s
assert 'Webserver offline' in s
assert 'PROBE ' not in s, 'diagnostics should start closed'
env['DISCORD_TEST_OPTIONS']='1'
subprocess.run([exe],env=env,check=True,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
s=Path(svg).read_text()
assert 'PROBE 80410100/80410100' in s, 'OPTIONS should reveal accurate failure reason'
assert 'CONNECTION ONLINE' not in s
print('PASS: forced HTTP+UDP bind failure -> offline UI, blocked QR, accurate probe code')
