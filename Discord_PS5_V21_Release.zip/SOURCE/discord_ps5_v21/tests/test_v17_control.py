from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'pc/control_center.html').read_text()
code=(root/'pc/companion.py').read_text()
assert "pc?'/status':'/api/status'" in html
assert "path.path == '/status'" in code
assert 'control_center.html' in code
assert 'Kanalsteuerung direkt auf PS5: noch nicht verfügbar' in html
assert 'V21' in html
print('PASS: V17 control center routes and honest feature labels')
