"""Confirm that routing-based PC-IP export rejects loopback and saves only IP."""
from pathlib import Path
import tempfile,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pc'))
import companion
original=companion.socket.socket
class FakeSock:
    def __init__(self,pc):self.pc=pc
    def __enter__(self):return self
    def __exit__(self,*a):return False
    def connect(self,address): assert address==('192.168.178.36',43670)
    def getsockname(self):return (self.pc,42000)
with tempfile.TemporaryDirectory() as folder:
    for local in ('192.168.178.100','127.0.0.1'):
        companion.socket.socket=lambda *args,**kwargs:FakeSock(local)
        path=Path(folder)/'bridge_ip.txt'
        try:
            if local.startswith('127'):
                try:companion.export_bridge_ip('192.168.178.36',path)
                except ValueError:pass
                else:raise AssertionError('Loopback exported')
            else:
                assert companion.export_bridge_ip('192.168.178.36',path)==local
                assert path.read_text()==local+'\n'
        finally:companion.socket.socket=original
print('PASS: Windows LAN-IP export and unsafe loopback rejection')
