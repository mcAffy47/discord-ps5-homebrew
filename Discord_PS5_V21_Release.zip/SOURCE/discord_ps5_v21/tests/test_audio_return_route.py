"""Mock audio discovery: isolated mode rejects non-Discord system-mix fallback."""
import threading,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pc'))
from v7_audio import DiscordAudio
class Speaker:
    def __init__(self,name):self.name=name;self.id=name
class FakeSoundcard:
    def __init__(self,speakers):self.speakers=speakers;self.default_calls=0;self.id_calls=[]
    def all_speakers(self):return self.speakers
    def default_speaker(self):self.default_calls+=1;return Speaker('Default system mix')
    def get_microphone(self,id,include_loopback):self.id_calls.append(id);raise OSError('Fixture capture stopped')
def test(speakers,strict):
    b=DiscordAudio.__new__(DiscordAudio)
    b.sc=FakeSoundcard(speakers);b.return_name='CABLE-B Input';b.allow_system_mix=not strict
    b.stop=threading.Event();b.capture_error=None
    b.capture_pc_sound()
    return b
b=test([],True)
assert b.capture_error is not None and 'zweites Windows' in str(b.capture_error)
assert b.sc.default_calls==1
b=test([Speaker('CABLE-B Input')],True)
assert b.sc.id_calls==['CABLE-B Input'] and b.sc.default_calls==0
b=test([],False)
assert b.sc.default_calls==1
print('PASS: dedicated Discord output selected; strict mode never captures system mix')
