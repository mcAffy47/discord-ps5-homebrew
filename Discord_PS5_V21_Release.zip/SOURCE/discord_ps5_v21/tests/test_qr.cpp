#include "qr_v3.hpp"
#include <cstdio>
#include <cassert>
int main(){
 discord_v9::LocalQR qr;
 assert(qr.encode("http://192.168.178.36:4747"));
 FILE* fp=fopen("/tmp/discord_v9_qr.pbm","wb");assert(fp);
 fprintf(fp,"P1\n%d %d\n",37,37);
 for(int y=-4;y<33;++y){for(int x=-4;x<33;++x){bool dark=x>=0&&y>=0&&x<29&&y<29&&qr.dark[y][x];fprintf(fp,"%d ",dark?1:0);}fprintf(fp,"\n");}
 fclose(fp);puts("QR PBM generated");
}
