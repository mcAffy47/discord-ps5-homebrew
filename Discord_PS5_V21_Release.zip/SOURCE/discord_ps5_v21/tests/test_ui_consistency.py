"""Portable source-level checks for all required UI and PC/PS5 handshake invariants.
Uses only Python standard library so users can run it in WSL during the build.
"""
from pathlib import Path
from html.parser import HTMLParser
import re
base=Path(__file__).resolve().parents[1]
main=(base/'src/main.cpp').read_text()
html_src=(base/'src/dashboard.hpp').read_text()
companion=(base/'pc/companion.py').read_text()
html=html_src.split('R"HTML(',1)[1].split(')HTML";',1)[0]
assert html.startswith('<!doctype html>')
assert len(html)<65000, 'Web page should be small enough for embedded HTTP response'
assert 'run_frames(draw,"Discord")' in main and 'DISCORD SERVER' in html
assert 'PAIRING CODE' in main, 'Host smoke test must be able to inspect pairing code'
assert 'http://%s:%d' in main, 'PS5 QR must contain dynamic URL'
assert 'PPSA12360' in (base/'build.sh').read_text()
assert 'TCP %08X' in main and 'UDP %08X' in main
assert 'activating || (online && qr_ready.load())' in main
assert 'stage.store(1)' in main
assert 'NOT IMPLEMENTED' in main, 'Do not present Discord voice as connected'
assert 'b\'PV10\'' in companion and '"PV10"' in main, 'Old PC/PS5 handshake missing'
assert 'b\'PV14\'' in companion and '"PV14"' in main, 'Outbound fallback handshake missing'
assert 'window.location.href' not in html
assert 'https://cdn' not in html and 'https://fonts.' not in html, 'No external front-end dependencies'
class IDs(HTMLParser):
    def __init__(self): super().__init__();self.ids=set()
    def handle_starttag(self, tag, attrs):
        for k,v in attrs:
            if k=='id':
                assert v not in self.ids, f'duplicate DOM id {v}'
                self.ids.add(v)
reader=IDs();reader.feed(html)
used=set(re.findall(r"\$\('([a-zA-Z0-9]+)'\)",html))
assert used<=reader.ids, f'Unresolved browser elements {used-reader.ids}'
for required in ('pairform','pair','inside','refresh','webstate','micstate','speakerstate','discordstate','host','tcperr','udperr','checks','meter'):
    assert required in reader.ids, required
print('PASS: browser DOM IDs, no external assets, 4747/QR, Discord honesty, PC/PS5 UDP handshake')
