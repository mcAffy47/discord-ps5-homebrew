"""No broadcast permission + denied explicit PS5 bind: known-PC unicast still works."""
from pathlib import Path
import os,socket,subprocess,threading,time
root=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v16_3_host_unicast'
subprocess.run(['clang++','-std=c++20','-Wall','-Wextra','-Werror','-pthread',
    '-I',str(root/'tests/host_include'),'-I',str(root/'src'),
    str(root/'src/main.cpp'),str(root/'tests/host_sce_shim.cpp'),'-o',exe],check=True)
srv=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
srv.bind(('127.0.0.1',43671));srv.settimeout(.3)
counts={'beacon':0,'pcm':0}
stop=threading.Event()
def worker():
    while not stop.is_set():
        try: pkt,peer=srv.recvfrom(2048)
        except socket.timeout:continue
        if pkt.startswith(b'PV14') and len(pkt)==12:
            counts['beacon']+=1
            srv.sendto(b'PA14'+pkt[4:],peer)
        elif pkt.startswith(b'PV7A') and len(pkt)==520:
            counts['pcm']+=1
            srv.sendto(pkt,peer)
th=threading.Thread(target=worker,daemon=True);th.start()
proc=subprocess.Popen([exe],env={**os.environ,'V14_FORCE_BIND_FAILURE':'1',
    'V14_DISABLE_BROADCAST':'1','DISCORD_BRIDGE_IP':'127.0.0.1'},
    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    deadline=time.monotonic()+7
    while time.monotonic()<deadline and counts['pcm']<5: time.sleep(.05)
    assert counts['beacon']>=1 and counts['pcm']>=5,counts
    print('PASS: broadcast disabled, PS5 listener bind denied, unicast audio connected:',counts)
finally:
    stop.set();proc.terminate()
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:proc.kill()
    th.join(timeout=1);srv.close()
