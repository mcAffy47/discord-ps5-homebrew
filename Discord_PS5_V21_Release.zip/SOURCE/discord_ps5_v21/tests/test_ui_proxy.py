"""Live loopback HTTP: reject cross-origin mutations; expose offline PS5 honestly."""
from pathlib import Path
import http.client,json,sys,threading
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pc'))
from companion import Companion
c=Companion('192.168.1.20','123456','','echo')
state={'mic_muted':0,'headset_muted':0,'headset_volume':100}
def mock_ps5(path,body=None):
    if path=='/api/status':return dict(state)
    if path=='/api/audio/control':
        state.update(mic_muted=int(chr(body[0])),headset_muted=int(chr(body[1])),headset_volume=int(body[2:]));return {'applied':True}
    raise AssertionError(path)
c.ps5_request=mock_ps5
threading.Thread(target=c.serve_oauth,daemon=True).start();assert c.oauth_ready.wait(2)
def req(method,path,body=None,origin=None):
    conn=http.client.HTTPConnection('127.0.0.1',8765,timeout=2)
    conn.request(method,path,body,{'Origin':origin} if origin else {})
    res=conn.getresponse();out=res.status,res.read();conn.close();return out
assert req('GET','/')[0]==200
assert req('POST','/api/audio/control','11050','http://evil.example')[0]==403
assert req('POST','/api/audio/control','11050')[0]==403
assert req('POST','/api/audio/control','11101','http://127.0.0.1:8765')[0]==400
assert req('POST','/api/audio/control','11050','http://127.0.0.1:8765')[0]==200
status,body=req('GET','/status');s=json.loads(body)
assert status==200 and s['ps5_web_available'] is True
assert s['headset_volume']==50 and s['mic_muted']==1
assert s['audio_active'] is False
c.ps5_request=lambda *args: (_ for _ in ()).throw(OSError('offline'))
status,body=req('GET','/status');assert json.loads(body)['ps5_web_available'] is False
assert req('POST','/api/audio/control','00100','http://127.0.0.1:8765')[0]==503
print('PASS: loopback UI, origin checks, validated proxy controls, offline status and 503')
