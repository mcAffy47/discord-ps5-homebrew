"""Ensure native PS5 color injection makes syntactically valid uint32 enum entries."""
from pathlib import Path
import tempfile,subprocess
base=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
    h=Path(d)/'demo_renderer.hpp'
    h.write_text('#pragma once\n#include <cstdint>\nenum class Color : std::uint32_t {\n'
                 'background = UINT32_C(0xff000000),\n'
                 'yellow = UINT32_C(0xff00ffff),\n};\n')
    subprocess.run(['python3',str(base/'tools/extend_colors.py'),str(h)],check=True)
    s=h.read_text()
    for name in ['blurple','discordBg','discordSidebar','discordGreen','discordRed']:
        assert name+' = UINT32_C(' in s,name
    assert 'blurple = UINT32_C(0xfff26558)' in s, 'Discord Blurple ABGR channel order wrong'
    c=Path(d)/'test.cpp'
    c.write_text('#include "demo_renderer.hpp"\nint main(){return static_cast<int>(Color::blurple)==0xfff26558u?0:1;}\n')
    subprocess.run(['clang++','-std=c++20','-Wall','-Wextra','-Werror',str(c),'-o',str(Path(d)/'test')],check=True)
    subprocess.run([str(Path(d)/'test')],check=True)
print('PASS: native PS5 color constants and ABGR Blurple validated')
