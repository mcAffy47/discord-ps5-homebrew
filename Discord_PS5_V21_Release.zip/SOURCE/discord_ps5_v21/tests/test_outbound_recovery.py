"""Check outbound LAN audio reconnects when Windows audio bridge stops replying.
Host shim emulates PS5 APIs; does NOT verify native console firmware.
"""
from pathlib import Path
import os, socket, subprocess, threading, time
base=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v16_1_host_recovery'
subprocess.run(['clang++','-std=c++20','-Wall','-Wextra','-Werror','-pthread',
    '-I',str(base/'tests/host_include'),'-I',str(base/'src'),
    str(base/'src/main.cpp'),str(base/'tests/host_sce_shim.cpp'),'-o',exe],check=True)
sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sock.bind(('0.0.0.0',43671));sock.settimeout(.2)
stop=threading.Event()
counts={'beacon':0,'first':0,'second':0}
mode={'state':'first'}
def server():
  while not stop.is_set():
    try: data,addr=sock.recvfrom(2048)
    except socket.timeout: continue
    if len(data)==12 and data[:4]==b'PV14':
      counts['beacon']+=1
      if mode['state']!='offline':
        sock.sendto(b'PA14'+data[4:10]+b'\r\n',addr)
    elif data.startswith(b'PV7A') and len(data)==520:
      if mode['state']=='first':
        counts['first']+=1
        sock.sendto(data,addr)
      elif mode['state']=='second':
        counts['second']+=1
        sock.sendto(data,addr)
thread=threading.Thread(target=server,daemon=True);thread.start()
p=subprocess.Popen([exe],env={**os.environ,'V14_FORCE_BIND_FAILURE':'1','DISCORD_HOST_BROADCAST_LOOPBACK':'1'},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
  deadline=time.monotonic()+5
  while counts['first']<5 and time.monotonic()<deadline:time.sleep(.05)
  assert counts['first']>=5,counts
  mode['state']='offline'
  original=counts['beacon']
  # PS5 must discard its old connected UDP socket and rediscover (~6 seconds).
  deadline=time.monotonic()+10
  while counts['beacon']<=original and time.monotonic()<deadline:time.sleep(.1)
  assert counts['beacon']>original,f'No reconnect beacon after silence: {counts}'
  mode['state']='second'
  deadline=time.monotonic()+5
  while counts['second']<5 and time.monotonic()<deadline:time.sleep(.05)
  assert counts['second']>=5,f'No restored audio after re-pairing: {counts}'
  print('PASS: outbound PS5 reconnects after Windows bridge outage:',counts)
finally:
  stop.set();p.terminate()
  try:p.wait(timeout=2)
  except subprocess.TimeoutExpired:p.kill()
  sock.close()
