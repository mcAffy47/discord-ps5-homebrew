#include "rx_sequence.hpp"
#include <cassert>
#include <cstdint>
int main(){
 lanvoice::RxSequence s;
 assert(s.accept(10));assert(s.accept(11));
 assert(!s.accept(11));assert(s.rejected==1);
 assert(s.accept(14));assert(s.gaps==2);
 assert(!s.accept(12));assert(s.rejected==2);
 s.reset();assert(s.accept(0xffffffffu));assert(s.accept(0));
 assert(s.gaps==2 && s.rejected==2);
}
