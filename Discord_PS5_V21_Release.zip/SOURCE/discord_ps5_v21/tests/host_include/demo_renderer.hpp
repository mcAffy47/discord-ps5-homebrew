#pragma once
#include <cstdio>
#include <thread>
#include <chrono>
namespace ps5 {namespace demo {
enum class Color { background, panel, white, cyan, yellow, mint, mintDark, muted, amber, ink, surface, stroke,discordBg,discordSidebar,discordSurface,discordRaised,discordStroke,blurple,blurpleDark,discordWhite,discordMuted,discordGreen,discordRed,discordAmber,discordBubble,discordCool};
struct Canvas { void clear(Color){};void rectangle(int,int,int,int,Color){};void circle(int,int,int,Color){};void text(int,int,const char* s,int,Color){ if(s && (s[0]=='P'||s[0]=='S'))std::fprintf(stderr,"SCREEN: %s\n",s); } };
template<typename F> void run_frames(F f, const char*) {for(int i=0;i<18;++i){Canvas c{};f(c);std::this_thread::sleep_for(std::chrono::milliseconds(500));}}
}}
