"""Regression: no silent stale audio if Windows loopback capture fails."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pc'))
from v7_audio import DiscordAudio
bridge=DiscordAudio.__new__(DiscordAudio)
bridge.capture_error=OSError('Sound device unavailable')
try:
    bridge.on_ps5_audio(b'\x00'*512)
except RuntimeError as exc:
    assert 'Loopback' in str(exc)
else:
    raise AssertionError('Silent failure: playback went on after PC loopback stopped')
print('PASS: Windows audio capture failures are surfaced instead of repeating old audio')
