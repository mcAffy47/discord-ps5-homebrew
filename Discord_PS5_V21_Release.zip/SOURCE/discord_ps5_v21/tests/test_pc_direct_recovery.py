"""After direct voice packet loss PC companion retries the PS5 handshake."""
import importlib.util,socket,threading,time,sys
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'pc'/'companion.py'
sys.path.insert(0,str(p.parent))
spec=importlib.util.spec_from_file_location('companion_direct_recovery',p)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
c=m.Companion('192.168.178.36','123456','','echo');c.ps5_ip='127.0.0.1'
ps5=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
ps5.bind(('127.0.0.1',43670));ps5.settimeout(5)
th=threading.Thread(target=c.serve_audio,daemon=True);th.start()
try:
    first,bridge_addr=ps5.recvfrom(4096)
    assert first==b'PV10123456\r\n',first
    ps5.sendto(m.audio_packet(1,b'\x01\x00'*256),bridge_addr)
    reply,_=ps5.recvfrom(4096)
    assert reply.startswith(b'PV7A') and len(reply)==520
    second,_=ps5.recvfrom(4096)
    assert second==first,second
    print('PASS: companion resumes direct handshake after previously successful audio')
finally:
    c.stop.set();ps5.close();th.join(timeout=2)
