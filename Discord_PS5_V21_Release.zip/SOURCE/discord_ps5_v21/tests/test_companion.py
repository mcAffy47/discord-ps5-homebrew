import importlib.util, socket, struct, sys, threading, time
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'pc'/'companion.py'
sys.path.insert(0,str(p.parent))
spec=importlib.util.spec_from_file_location('companion',p)
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)
assert c.validate_ip('192.168.178.36') == '192.168.178.36'
for invalid in ('127.0.0.1','8.8.8.8','169.254.1.1'):
    try:c.validate_ip(invalid)
    except ValueError:pass
    else:raise AssertionError('Accepted invalid address '+invalid)
assert len(c.audio_packet(45,b'\0'*512))==520
assert c.packet_valid(c.audio_packet(45,b'\0'*512))
assert not c.packet_valid(b'PV7A')
a=c.Companion('192.168.178.36','123456','123456789012345678','echo')
url=a.oauth_start()
assert 'code_challenge_method=S256' in url and 'client_id=123456789012345678' in url
assert 'scope=identify' in url and 'code_verifier' not in url
assert len(a.oauth_sessions)==1
print('PASS: private IP validation, UDP PCM format, OAuth2 PKCE/CSRF state')
# Mock the external Discord code exchange; verify callback path and data minimization.
from io import BytesIO
old_urlopen = c.urllib.request.urlopen
sent=[]
def mocked_open(req, timeout=None):
    url = req.full_url if hasattr(req, 'full_url') else req
    if url.endswith('/oauth2/token'):
        assert b'code_verifier=' in req.data and b'client_id=' in req.data
        assert b'client_secret=' not in req.data
        return BytesIO(b'{"access_token":"private-access-token"}')
    if url.endswith('/users/@me'):
        assert req.get_header('Authorization')=='Bearer private-access-token'
        return BytesIO(b'{"username":"PS5User"}')
    raise AssertionError(url)
a.report_discord = lambda name: sent.append(name)
c.urllib.request.urlopen=mocked_open
try:
    state=next(iter(a.oauth_sessions))
    assert a.oauth_callback(state,'discord-code')=='PS5User'
    assert sent==['PS5User']
    try:a.oauth_callback(state,'duplicate')
    except ValueError:pass
    else:raise AssertionError('Reused state accepted')
finally:
    c.urllib.request.urlopen=old_urlopen
print('PASS: mocked Discord PKCE token exchange and identity, state replay rejected')
