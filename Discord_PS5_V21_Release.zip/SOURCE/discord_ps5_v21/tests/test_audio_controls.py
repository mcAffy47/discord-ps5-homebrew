"""Exercise authenticated controls against the native host simulation and PCM wire."""
from pathlib import Path
import http.client,json,os,re,socket,struct,subprocess,time
base=Path(__file__).resolve().parents[1]
exe='/tmp/discord_v19_controls'
subprocess.run([os.environ.get('CXX','c++'),'-std=c++20','-Wall','-Wextra','-Werror','-pthread','-I',str(base/'tests/host_include'),'-I',str(base/'src'),str(base/'src/main.cpp'),str(base/'tests/host_sce_shim.cpp'),'-o',exe],check=True)
output_log=Path('/tmp/discord_v19_output.log');output_log.unlink(missing_ok=True)
p=subprocess.Popen([exe],stderr=subprocess.PIPE,text=True,env={**os.environ,"V19_TEST_MIC_NONZERO":"1","V19_TEST_OUTPUT_LOG":str(output_log)})
def request(method,path,body=None,cookie=None):
    c=http.client.HTTPConnection('127.0.0.1',14747,timeout=2)
    c.request(method,path,body,{'Cookie':cookie} if cookie else {})
    r=c.getresponse();out=r.status,r.getheaders(),r.read();c.close();return out
try:
    for line in p.stderr:
        m=re.search(r'PAIRING CODE   (\d{6})',line)
        if m:break
    else:raise AssertionError('No pairing marker')
    code=m.group(1).encode()
    for _ in range(20):
        try:
            request('GET','/');break
        except ConnectionRefusedError:time.sleep(.05)
    assert request('POST','/api/audio/control',b'11050')[0]==401
    status,h,_=request('POST','/api/pair',code)
    assert status==200
    cookie=next(v.split(';')[0] for k,v in h if k.lower()=='set-cookie')
    assert request('POST','/api/discord/device',b'300\nABCD-EFGH')[0]==401
    assert request('POST','/api/discord/device',b'300\nABCD-EFGH',cookie)[0]==200
    assert request('POST','/api/discord/device',b'9999\nABCD',cookie)[0]==400
    assert request('POST','/api/discord/device',b'300\n<script>',cookie)[0]==400
    assert request('POST','/api/discord/device',b'0\n',cookie)[0]==200
    for bad in (b'',b'11abc',b'21100',b'11101',b'11050x'):
        assert request('POST','/api/audio/control',bad,cookie)[0]==400,bad
    assert request('POST','/api/audio/control',b'11050',cookie)[0]==200
    status,_,body=request('GET','/api/status',cookie=cookie)
    s=json.loads(body);assert status==200
    assert (s['mic_muted'],s['headset_muted'],s['headset_volume'])==(1,1,50),s
    udp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);udp.bind(('127.0.0.1',0));udp.settimeout(1)
    udp.sendto(b'PV10'+code+b'\r\n',('127.0.0.1',43670))
    for _ in range(4):
        data,_=udp.recvfrom(2048)
        assert len(data)==520 and data[:4]==b'PV7A'
        assert data[8:]==bytes(512),'Muted microphone leaked samples'
        udp.sendto(data,('127.0.0.1',43670))
    assert request('POST','/api/audio/control',b'00100',cookie)[0]==200
    end=time.monotonic()+1
    heard=False
    while time.monotonic()<end:
        data,_=udp.recvfrom(2048)
        if any(data[8:]):heard=True;break
    assert heard,'Unmute failed to restore captured microphone'
    time.sleep(.6)  # Startup self-test tone has completed before checking gain.
    assert request('POST','/api/audio/control',b'00050',cookie)[0]==200
    start=len(output_log.read_text().splitlines())
    for _ in range(20):
        data,_=udp.recvfrom(2048);udp.sendto(data,('127.0.0.1',43670))
    time.sleep(.05)
    peaks=list(map(int,output_log.read_text().splitlines()[start:]))
    assert 600 in peaks,peaks  # Known 1200 microphone fixture at 50% speaker gain.
    assert request('POST','/api/audio/control',b'01050',cookie)[0]==200
    time.sleep(.05)
    assert set(map(int,output_log.read_text().splitlines()[-5:]))=={0},'Deafen leaked audio'
    udp.close()
    print('PASS: auth, bounds, mute/deafen/volume state, silent wire packets, microphone unmute, 50% output gain, silent deafen')
finally:
    p.terminate();p.communicate(timeout=3)
