#include "http_protocol.hpp"
#include <cassert>
#include <cstring>
#include <cstdio>
int main(){
 const char *valid="GET /api/status HTTP/1.1\r\nHost: localhost\r\n\r\n";
 auto r=discord_v9::parse_request(valid,strlen(valid));assert(r.valid);assert(discord_v9::same(r.path,"/api/status"));
 const char *invalid="GET /../secret HTTP/1.1\r\n\r\n";assert(!discord_v9::parse_request(invalid,strlen(invalid)).valid);
 const char *hdr="GET / HTTP/1.1\r\nCookie: ps5_session=0123456789abcdef0123456789abcdef; theme=dark\r\n\r\n";
 assert(discord_v9::token_from_cookie(hdr,strlen(hdr),"0123456789abcdef0123456789abcdef"));
 assert(!discord_v9::token_from_cookie(hdr,strlen(hdr),"1123456789abcdef0123456789abcdef"));
 std::puts("PASS V9 protocol URL traversal rejected, cookie auth checked");
}
