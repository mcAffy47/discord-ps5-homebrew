#pragma once
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <thread>
namespace ps5 {namespace demo {
enum class Color {background,panel,white,cyan,yellow,mint,mintDark,muted,amber,ink,surface,stroke,discordBg,discordSidebar,discordSurface,discordRaised,discordStroke,blurple,blurpleDark,discordWhite,discordMuted,discordGreen,discordRed,discordAmber,discordBubble,discordCool};
struct Canvas {
 FILE* f;
 explicit Canvas(FILE* fp):f(fp){}
 const char* col(Color c) {switch(c){case Color::background:return "#090e1c";case Color::panel:return "#162039";case Color::white:return "#f4f7ff";case Color::cyan:return "#6cebe3";case Color::yellow:return "#ffcb71";case Color::mint:return "#58e2c5";case Color::mintDark:return "#113d42";case Color::muted:return "#97acc5";case Color::amber:return "#ffbb77";case Color::ink:return "#101729";case Color::surface:return "#1e2944";case Color::stroke:return "#293954";case Color::discordBg:return "#1e1f22";case Color::discordSidebar:return "#121318";case Color::discordSurface:return "#2b2d31";case Color::discordRaised:return "#313338";case Color::discordStroke:return "#41434a";case Color::blurple:return "#5865f2";case Color::blurpleDark:return "#39439b";case Color::discordWhite:return "#f2f3f5";case Color::discordMuted:return "#b5bac1";case Color::discordGreen:return "#23a559";case Color::discordRed:return "#f23f43";case Color::discordAmber:return "#f0b232";case Color::discordBubble:return "#35385c";case Color::discordCool:return "#99a1ff";}return "#fff";}
 void clear(Color c){rectangle(0,0,1920,1080,c);}
 void rectangle(int x,int y,int w,int h,Color c){std::fprintf(f,"<rect x='%d' y='%d' width='%d' height='%d' fill='%s' />\n",x,y,w,h,col(c));}
 void circle(int x,int y,int r,Color c){std::fprintf(f,"<circle cx='%d' cy='%d' r='%d' fill='%s'/>\n",x,y,r,col(c));}
 void text(int x,int y,const char* s,int size,Color c){
  const char* orig=s;
  if(s && (s[0]=='P'||s[0]=='S'))std::fprintf(stderr,"SCREEN: %s\n",s);
  std::fprintf(f,"<text x='%d' y='%d' dominant-baseline='hanging' font-family='DejaVu Sans Mono' font-size='%d' fill='%s'>",x,y,size*8+1,col(c));
  for(;*s;++s){switch(*s){case '&':std::fputs("&amp;",f);break;case '<':std::fputs("&lt;",f);break;case '>':std::fputs("&gt;",f);break;default:std::fputc(*s,f);}}
  std::fputs("</text>\n",f);(void)orig;
 }
};
template<typename F>void run_frames(F draw,const char*){
 std::this_thread::sleep_for(std::chrono::milliseconds(1200));
 const char* path=std::getenv("DISCORD_SNAPSHOT_SVG");
 if(!path)return;
 FILE*f=std::fopen(path,"wb");if(!f)return;
 std::fputs("<svg xmlns='http://www.w3.org/2000/svg' width='1920' height='1080' viewBox='0 0 1920 1080'>",f);
 Canvas canvas(f);draw(canvas);
 std::fputs("</svg>",f);std::fclose(f);
}
}}
