$ErrorActionPreference = 'Stop'
$sourcePath = (& wsl.exe -- wslpath -u $PSScriptRoot | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or -not $sourcePath.StartsWith('/')) { throw 'WSL konnte den Projektordner nicht finden.' }
$shellSource = "'" + $sourcePath.Replace("'", "'\''") + "'"
$buildScript = @'
set -e
src=__SOURCE__
root="$HOME/ps5-native-app-boilerplate"
test -s "$root/Makefile" || { echo 'FEHLER: Vorhandenes PS5-Boilerplate fehlt.'; exit 2; }
mkdir -p "$root/discord_ps5_v21"
cp -R "$src/." "$root/discord_ps5_v21/"
bash "$root/discord_ps5_v21/build.sh"
'@
$buildScript = $buildScript.Replace('__SOURCE__', $shellSource)
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($buildScript))
& wsl.exe -- bash -lc "echo $encoded | base64 -d | bash"
exit $LASTEXITCODE
