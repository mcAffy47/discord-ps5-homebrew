#!/usr/bin/env bash
set -euo pipefail
PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ROOT=${DISCORD_BUILD_ROOT:-"$HOME/discord-ps5-build"}
COMMIT=b8dc4a3fe2e05e826b037bd68824751c7468a6d7
if [ ! -e "$ROOT" ]; then
 git clone https://github.com/blackbearreloaded/ps5-native-app-boilerplate.git "$ROOT"
 git -C "$ROOT" checkout --detach "$COMMIT"
fi
[ "$(git -C "$ROOT" rev-parse HEAD)" = "$COMMIT" ] || { echo 'FEHLER: Buildordner verwendet einen anderen Boilerplate-Stand.';exit 2; }
DISCORD_BUILD_ROOT="$ROOT" bash "$PACKAGE/build.sh"
