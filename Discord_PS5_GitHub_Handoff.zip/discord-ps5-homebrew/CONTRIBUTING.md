# Continuing the project

Maintenance is open. Fork the repository or open an issue to discuss taking over. Keep attribution and the included GPL license and third-party notices.

Report the exact firmware, loader, build, controller connection and audio device. Include sanitized diagnostics and reproduction steps. Never upload tokens or client secrets. Distinguish source inspection, host simulation, native compilation and real hardware evidence.

Prefer small, documented fixes and bundled hardware test rounds. Do not invent connected Discord members/channels in the UI. Keep the PS5-centered network design and unrelated homebrew projects separate. See docs/HANDOVER.md for the remaining technical work.
