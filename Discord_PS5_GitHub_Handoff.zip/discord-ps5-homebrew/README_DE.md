# Discord – V21 Voice UI Beta

Fertig kompiliertes PS5-Homebrew mit Discord-inspirierter Oberfläche, Controller-Steuerung und Windows-Audiobrücke. App-Kennung: PPSA12360. Dies ist kein offizieller Discord-Client.

## Neu in V21

Discord-inspirierter Sprachbereich mit zwei Gerätekacheln, gezeichneten Audio-Symbolen, Sprechindikator, segmentiertem Pegel und Lautstärkebalken. OPTIONS öffnet Verbindungsdetails; Kreis schließt sie. Browseroberfläche mit passenden Gerätekacheln und Bereichsnavigation. Bei Verbindungsverlust wird der Sprechindikator zurückgesetzt.

## Installation

1. ZIP vollständig entpacken. Die bisherige Discord-App schließen und deren App-Ordner sichern.
2. Den vollständigen Ordner PPSA12360 wie bei deinem bisherigen Homebrew-Build übertragen (bei entsprechender Loader-Einrichtung nach /data/homebrew/). eboot.bin, sce_sys und sce_module zusammen kopieren. Gleiche App-Kennung wie zuvor.
3. Discord auf der PS5 starten.
4. Am Windows-PC PC/start_windows.cmd starten. Python 3.9 oder neuer wird benötigt. Für Audio ggf. zuvor PC/install_discord_audio.cmd ausführen.
5. PS5-IP und aktuellen Kopplungscode eingeben. Modus 2 nutzt den Windows-Standardmix; dabei können weitere PC-Töne mitkommen. Modus 3 nutzt ein separates vorhandenes Ausgabegerät.
6. Server und Sprachkanal im offiziellen Windows-Discord auswählen. Die Windows-Brücke bleibt erforderlich.

## Controller

- Steuerkreuz hoch/runter: Audio-Regler auswählen.
- X: ausgewählte Stummschaltung umschalten.
- Quadrat: Mikrofon stumm/aktiv.
- Dreieck: Kopfhörer stumm/aktiv.
- L1/R1: Lautstärke um 5 Prozent senken/erhöhen.
- Beim ausgewählten Lautstärkeregler funktionieren auch links/rechts.

Stummschaltung hält die Audioverbindung offen. Die Regler ändern den PS5-Audioweg, nicht Discords eigenes Mute-Symbol. Einstellungen gelten bis zum Neustart.

## Browser und Geräteanmeldung

Der PC öffnet http://127.0.0.1:8765/. Der normale PS5-QR öffnet die lokale PS5-Steuerseite auf Port 4747. Wenn dieser Webserver nicht erreichbar ist, kann UDP-Audio dennoch funktionieren; Browser-Regler und Codeübermittlung sind dann eingeschränkt.

Optional ist ein Gerätecode-Anmeldefluss implementiert. Er benötigt eine entsprechend zugelassene Discord-Developer-App und DISCORD_CLIENT_ID sowie DISCORD_CLIENT_SECRET als Umgebungsvariablen ausschließlich auf dem PC. Die Oberfläche kann dann einen Gerätecode anfordern. Auf der PS5 erscheint zeitlich begrenzt ein QR zu https://discord.com/activate mit dem separat einzugebenden Code. Es handelt sich nicht um Discords normalen QR-Login. Geheimnis und Zugriffstoken werden nur im PC-Prozess gehalten. Diese Anmeldung ist noch nicht live geprüft und aktiviert keinen direkten Sprachkanalbeitritt.

## Geprüft und noch offen

Der native PS5-Build mit Clang 18.1.3 und PS5 Payload SDK v0.42 ist erfolgreich. Dateiformat und Build-Integritätsprüfung bestanden. BUILD_MANIFEST.json enthält die Prüfsumme. TEST_RESULTS.json dokumentiert 23 Host-Testskripte; beim QR-Test war die automatische Bilddecodierung nicht verfügbar, die Matrixgenerierung wurde geprüft. Netzwerkprüfungen sind lokale Simulationen. Die Vorschau stammt aus dem nativen Zeichen-Code und ist kein Foto von einer PS5.

Nicht geprüft: Start und Audio auf echter PS5, Controller auf echter Hardware, Windows-Geräteauswahl und Live-Discord-Geräteanmeldung. Direkte Server-/Kanalauswahl auf der PS5 und Sprachchat parallel zu einem Spiel sind noch offen. LAN-Audio ist derzeit unverschlüsselt. Die separate PS SAVEDATA-App wurde nicht geändert.

Ein erster Hardwaretest: App startet; Quadrat schaltet das Mikrofon; L1/R1 ändern die Lautstärke; Audio funktioniert in beide Richtungen.

## Selbst bauen

In diesem Repository liegt der Quellcode direkt im Stammordner; im Release-ZIP unter SOURCE/discord_ps5_v21. build_standalone.sh richtet den festgelegten öffentlichen Boilerplate-Stand ein und ruft build.sh auf. Benötigt werden eine Linux-/WSL-Cross-Build-Umgebung, Clang/LLVM, Ninja und die Abhängigkeiten des Boilerplates. BUILD_WINDOWS.cmd nutzt deine bestehende WSL-Toolchain. Der AudioIn-Importstub ist enthalten. Versionsstände und Lizenzen: BUILD_MANIFEST.json, THIRD_PARTY_NOTICES.md und LICENSE.
