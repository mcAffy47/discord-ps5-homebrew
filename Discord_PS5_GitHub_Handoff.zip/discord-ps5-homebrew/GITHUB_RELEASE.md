# V21 Voice UI Beta — community handoff

Native PS5 app with a Discord-inspired interface, controller audio controls and a Windows audio bridge. Development paused; maintainers welcome.

Download and fully extract Discord_PS5_V21_Release.zip, then read START_HIER.txt. It contains PPSA12360, PC and source folders. Not a PKG installer.

Earlier versions had user-confirmed bidirectional audio. This V21 binary was compiled and integrity-checked, with 23 passing host test programs, but has not been verified on actual PS5 hardware. Windows remains required. Direct Discord voice join/leave, live device authorization and in-game background voice remain incomplete or unverified.

See README and docs/HANDOVER.md before continuing development. SHA256SUMS.txt in the release section identifies the archive.
