# Projektstand und bisherige Erkenntnisse

AFFrad stellt die aktive Entwicklung vorerst ein. Andere Entwickler dürfen unter der enthaltenen Lizenz weiterarbeiten, forken und Verbesserungen vorschlagen. Das Projekt entstand mit KI-Unterstützung; Konsolentests führte der Nutzer selbst durch.

## Verlauf

- Frühe Versionen: native PS5-App und Headset-/Mikrofonzugriff aufgebaut; mehrere Echo- und Audiotests.
- V15–V18: PS5/Windows-Audiotransport schrittweise verbessert. Am Ende wurden beide Audiowege vom Nutzer als funktionierend bestätigt. Die kostenlose Windows-Rückkanalvariante wurde ergänzt.
- V19: Discord-inspirierte native und Browser-Oberfläche, Audio-Regler und geschützte Steuer-API.
- V20: native Controller-Anbindung, optionaler Gerätecode-Anmeldefluss, kompilierter PS5-Build.
- V21: Sprachkacheln, gezeichnete Audio-Symbole, Sprechindikator, Pegel- und Lautstärkebalken, OPTIONS-Diagnose und passende Browseransicht.

## Beobachtete Probleme

Auf dem getesteten 13.60-Setup war der Browser-Webserver wiederholt nicht erreichbar. Windows meldete WinError 10061. PS5-Bind-Diagnosen und ausgehende Verbindungswege wurden ergänzt. Die genaue Ursache auf der Konsole ist nicht abschließend geklärt.

Beim Echo-Test war die eigene Stimme mit Verzögerung zu hören. Dieser Testmodus ist nicht mit einem normalen Discord-Gespräch gleichzusetzen. Der Windows-Standardmix kann weitere PC-Töne auf das Headset übertragen. Die Variante mit separatem vorhandenem Ausgabegerät soll das vermeiden; eine gekaufte CABLE-B-Lösung ist nicht zwingend nötig.

Frühere OAuth-Versuche waren problematisch. Ein leeres Client-ID-Feld erlaubt weiterhin die lokale Audiobrücke. Kein normaler Discord-QR-Login und kein eigenständiger Sprachkanalbeitritt sind fertiggestellt.

## Nächste sinnvolle gebündelte Hardwareprüfung

1. Vollständige V21-App starten und Darstellung prüfen.
2. Quadrat, Dreieck, L1/R1 sowie OPTIONS/Kreis prüfen.
3. Audiobrücke koppeln und beide Audiowege prüfen.
4. Erreichbarkeit von http://<PS5-IP>:4747 sowie Diagnosewerte festhalten.

Keine Firmwareänderung für diesen Test vornehmen. Der Test muss die tatsächlich verwendete Firmware, Loader-Version, Controller-Verbindung und das Headset dokumentieren. Bisherige Angaben begründen keine pauschale Kompatibilitätszusage.

## Projektgrenzen

App heißt Discord, Title-ID PPSA12360. PS SAVEDATA und Firefox PS5 bleiben vollständig getrennt. Ziel bleibt ein kleiner, controllerbedienbarer Voice-Client statt Textchat oder einer umfangreichen Discord-Nachbildung. Der aktuelle Windows-Brückenansatz erreicht dieses Endziel noch nicht.
