# Developer handover — V21

## Components

| Path | Responsibility |
| --- | --- |
| src/main.cpp | PS5 startup, HTTP API, UDP audio, native UI, pad polling |
| src/controller_ui.hpp | Button edges, selection, mute/volume actions, diagnostics toggle |
| src/ps5_pad.hpp | Pad ABI definitions retained from upstream research |
| src/dashboard.hpp | Embedded local control page |
| pc/control_center.html | Same page served by the PC companion |
| pc/companion.py | Pairing, audio transport, local UI/proxy and account flow |
| pc/device_auth.py | Optional device authorization state machine |
| pc/v7_audio.py | Windows audio capture/playback integration |
| tests/ | Unit checks and host HTTP/UDP/audio simulations |
| imports/libSceAudioIn.so | Link-time import shim from an earlier project build |

Keep the embedded dashboard and PC HTML in sync. The import shim is not Sony's AudioIn implementation; the console provides the runtime module. Its provenance and hash are recorded in THIRD_PARTY_NOTICES.md.

## Network design

The PS5 hosts TCP 4747. LAN users enter the PS5 IP in the browser; no fixed PC IP is compiled into the PS5 app. Pairing uses a six-digit displayed code and subsequent HTTP cookie authorization. The PC loopback UI uses TCP 8765 and proxies PS5 controls after pairing. Origin checks restrict browser control requests at the PC endpoint.

Direct PS5 UDP audio uses 43670; the PC outbound-discovery path uses 43671. Existing protocol markers include PV10 for direct handshake, PV14 for outbound discovery, PA14 acknowledgment and PV7A for PCM packets. Tests exercise matching pairing, reconnect behavior, packet sequence accounting and mute/gain behavior. These custom packets are **not Discord's voice protocol**.

The outbound path was introduced because PS5 listener binds failed on the author's setup. A working UDP audio path does not imply that HTTP 4747 is reachable. UI control and device-code delivery can be unavailable while audio continues.

POST /api/audio/control accepts a validated five-character payload MDVVV: microphone mute 0/1, headphone mute 0/1, volume 000–100. Native controller actions modify the same audio state. Muting preserves the stream by sending silence. Gain and headphone mute are applied to playback.

## Authentication

Two distinct experimental paths exist:

- Existing PC OAuth identity flow: identify scope, local redirect http://127.0.0.1:8765/callback, PKCE and state checks. Mock coverage is not proof of a successful live login.
- Optional device-code flow: DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET on the PC; code issuance/polling, expiry and error handling. Appropriate service-side application access is required. Verify current Discord requirements before extending it. No live success was established.

The ordinary PS5 QR links to the local dashboard. During device activation it temporarily links to discord.com/activate; the separately displayed code must be entered there. It is not Discord's standard client QR login. Tokens and the client secret are held in PC process memory by this implementation. Do not add them to public logs or repository files.

## Input and rendering

1920×1080 native CPU-rendered interface; D-pad selects one of three audio controls. Cross toggles selected mute, Square toggles mic, Triangle toggles output, L1/R1 change volume by 5. Options toggles diagnostics; Circle closes them. Input is edge-triggered and seeds state on reconnection/system-owned input to avoid activating a held button.

The host preview is an SVG approximation of native draw calls. It uses a different font and is not a pixel-identical console screenshot.

## Evidence and limitations

Earlier user-run hardware tests confirmed bidirectional PS5/Windows audio, but not all later changes. V21's build and host checks were performed during development; V21 hardware, Windows-device selection, live authorization and background-game operation remain unverified. TEST_RESULTS.json includes the diagnostic test rerun after it was adapted to open the new Options panel.

Known concerns: bind errors, echo-test delay/feedback, Windows system-mix audio leakage, lack of encrypted LAN audio, no adaptive jitter buffer, and no native real Discord voice-channel join/leave. Test fixture addresses are local examples; users must enter their own IP.

## Source pins

- Boilerplate: b8dc4a3fe2e05e826b037bd68824751c7468a6d7
- Pad research: bda3543ab4a070a385e605c9b8981fb4a7faadcd
- Public payload SDK: v0.42

A rebuild needs the pinned external dependencies and compatible toolchain. The GitHub handoff does not claim a freshly reproduced build; it preserves the delivered V21 app and source, with documentation and packaging cleanup.
